
var NodeUtil = require("./game/TB_NodeUtil.js");
var FileUtil = require("./game/TB_FileUtil.js");
var Iter = require("./game/TB_Iter.js").Iter;

function findAllDisplays(groupName) {
  var displays = [];
  for (var i = 0; i < node.numberOfSubNodes(groupName); i++)
  {
    var nodeName = node.subNode(groupName, i);
    var type = node.type(nodeName);
    if (type == "DISPLAY")
    {
      displays.push(nodeName);
    }
    else if (type == "GROUP")
    {
      displays = displays.concat(findAllDisplays(nodeName)); // Recursively find all displays in inner group.
    }
  }
  return displays;
}

function checkedAndEnabled(cb) {
  return cb.checked && cb.enabled;
}

function showUI() {
  /**
   * @type {{
   * gbDirectory: {
   *  savePath: { text: string },
   *  saveName: { text: string },
   *  pathBtn: { clicked: function }
   * },
   * gbOptions: {
   *  cbDisplay: { addItem: function, clear: function, currentText: string }
   *  cbUseSceneMarkers: { checked: boolean }
   * },
   * gbSpriteSheet: {
   *  cbIndividualSprites: { checked: boolean },
   *  MaxWidth: { value: number },
   *  MaxHeight: { value: number },
   *  cbJsonFormat: { currentText: string },
   *  cbRemoveEmptyFrames: { checked: boolean },
   *  cbRemoveDuplicateFrames: { checked: boolean },
   *  cbRemovePerframeWhitespace: { checked: boolean }
   * },
   * gbResolution: {
   *  tblResolution: { rowCount: number, columnCount: number, setItem: function }
   * },
   *  btnExport: { clicked: function },
   *  btnCancel: { clicked: function }
   * }}
   */
  var ui = UiLoader.load("TB_ExportToJSONSpriteSheets.ui");

  // Custom sync for Display --- gather all displays from scene and set them to the dropdown.
  var displays = findAllDisplays("Top");
  ui.gbOptions.cbDisplay.clear();
  for (var i = 0; i < displays.length; i++)
  {
    ui.gbOptions.cbDisplay.addItem(displays[i]);
  }

  // Connect all UI elements.
  {
    ui.btnCancel.clicked.connect(function () {
      ui.close();
    });
    ui.gbDirectory.btnDefaultPath.clicked.connect(function () {
      ui.gbDirectory.savePath.setText(FileUtil.currentProjectPath());
    });
    ui.gbResolution.btnAddRes.clicked.connect(function () {
      ui.gbResolution.tblResolution.insertRow(ui.gbResolution.tblResolution.rowCount);
    });
    UiLoader.setSvgIcon(ui.gbResolution.btnAddRes, "colour/addcolour.svg");
    ui.gbResolution.btnRemRes.clicked.connect(function () {
      ui.gbResolution.tblResolution.removeRow(ui.gbResolution.tblResolution.currentRow());
    });
    UiLoader.setSvgIcon(ui.gbResolution.btnRemRes, "colour/deletecolour.svg");

    // Populate JSON format dropdown.
    {
      ui.gbSpriteSheet.cbJsonFormat.addItem("None");
      ui.gbSpriteSheet.cbJsonFormat.addItem("Unreal Paper 2D");
      ui.gbSpriteSheet.cbJsonFormat.addItem("EaselJS");
    }

    // Max Width, Max Height, JSON Format, and Sheet optimizations are enabled if cbIndividualSprites is unchecked.
    // Sheet optimizations are enabled if JSON Format is not None.
    {
      function syncSpriteSheetPreferences() {
        var sheetEnabled = !ui.gbSpriteSheet.cbIndividualSprites.checked;
        var jsonEnabled = ui.gbSpriteSheet.cbJsonFormat.currentText != "None";
        ui.gbSpriteSheet.MaxWidth.enabled = sheetEnabled;
        ui.gbSpriteSheet.MaxHeight.enabled = sheetEnabled;
        ui.gbSpriteSheet.cbJsonFormat.enabled = sheetEnabled;
        ui.gbSpriteSheet.cbRemoveEmptyFrames.enabled = sheetEnabled && jsonEnabled;
        ui.gbSpriteSheet.cbRemoveDuplicateFrames.enabled = sheetEnabled && jsonEnabled;
        ui.gbSpriteSheet.cbRemovePerframeWhitespace.enabled = sheetEnabled && jsonEnabled;
      }
      ui.gbSpriteSheet.cbIndividualSprites.stateChanged.connect(syncSpriteSheetPreferences);
      ui.gbSpriteSheet.cbJsonFormat.currentIndexChanged.connect(syncSpriteSheetPreferences);
      syncSpriteSheetPreferences();
    }
  }

  // Set all UI elements from preferences.getString or preferences.getNumber.
  {
    ui.gbDirectory.savePath.text = preferences.getString("ExportToJSON.savePath", FileUtil.currentProjectPath());
    ui.gbDirectory.saveName.text = preferences.getString("ExportToJSON.saveName", scene.currentScene());
    ui.gbOptions.cbUseSceneMarkers.checked = preferences.getBool("ExportToJSON.cbUseSceneMarkers", true);
    ui.gbSpriteSheet.cbIndividualSprites.checked = preferences.getBool("ExportToJSON.cbIndividualSprites", false);
    ui.gbSpriteSheet.MaxWidth.value = preferences.getInt("ExportToJSON.MaxWidth", 8192);
    ui.gbSpriteSheet.MaxHeight.value = preferences.getInt("ExportToJSON.MaxHeight", 8192);
    ui.gbSpriteSheet.cbJsonFormat.currentText = preferences.getString("ExportToJSON.cbJsonFormat", "EaselJS");
    ui.gbSpriteSheet.cbRemoveEmptyFrames.checked = preferences.getBool("ExportToJSON.cbRemoveEmptyFrames", false);
    ui.gbSpriteSheet.cbRemoveDuplicateFrames.checked = preferences.getBool("ExportToJSON.cbRemoveDuplicateFrames", false);
    ui.gbSpriteSheet.cbRemovePerframeWhitespace.checked = preferences.getBool("ExportToJSON.cbRemovePerframeWhitespace", false);

    // Display found from scene, set it to the dropdown.
    {
      var currentDisplay = ui.gbOptions.cbDisplay.findText(preferences.getString("ExportToJSON.display", "Top"));
      ui.gbOptions.cbDisplay.setCurrentIndex(currentDisplay == -1 ? 0 : currentDisplay);
    }

    // Populate table from preferences - name, width, height columns per resolution row.
    {
      var resolutionCount = preferences.getInt("ExportToJSON.resolutionCount", 1);
      ui.gbResolution.tblResolution.rowCount = resolutionCount;
      for (var i = 0; i < resolutionCount; i++)
      {
        // Per resolution index, get name, width, height as .0.name, .0.width, .0.height ...
        var name = preferences.getString("ExportToJSON." + i + ".name", "FullHD");
        var width = preferences.getInt("ExportToJSON." + i + ".width", 1920);
        var height = preferences.getInt("ExportToJSON." + i + ".height", 1080);
        ui.gbResolution.tblResolution.setItem(i, 0, new QTableWidgetItem(name));
        ui.gbResolution.tblResolution.setItem(i, 1, new QTableWidgetItem(width.toString()));
        ui.gbResolution.tblResolution.setItem(i, 2, new QTableWidgetItem(height.toString()));
      }
    }
  }

  // Save Path button to explore.
  ui.gbDirectory.pathBtn.clicked.connect(function () {
    var path = ui.gbDirectory.savePath.text;
    if (path == "")
    {
      path = FileUtil.currentProjectPath();
    }
    var path = FileDialog.getExistingDirectory(path, "Select Save Path", ui);
    if (path != "")
    {
      ui.gbDirectory.savePath.text = path;
    }
  });

  // Export button.
  ui.btnExport.clicked.connect(function () {

    // Ensure that the export path is valid.
    var dir = new QDir(ui.gbDirectory.savePath.text);
    if (!dir.exists())
    {
      MessageBox.information(translator.tr("Invalid directory: ") + ui.gbDirectory.savePath.text);
      return;
    }

    try
    {

      // Sync back the UI to the preferences.
      {
        preferences.setString("ExportToJSON.savePath", ui.gbDirectory.savePath.text);
        preferences.setString("ExportToJSON.saveName", ui.gbDirectory.saveName.text);
        preferences.setString("ExportToJSON.display", ui.gbOptions.cbDisplay.currentText);
        preferences.setBool("ExportToJSON.cbUseSceneMarkers", ui.gbOptions.cbUseSceneMarkers.checked);
        preferences.setBool("ExportToJSON.cbIndividualSprites", ui.gbSpriteSheet.cbIndividualSprites.checked);
        preferences.setInt("ExportToJSON.MaxWidth", ui.gbSpriteSheet.MaxWidth.value);
        preferences.setInt("ExportToJSON.MaxHeight", ui.gbSpriteSheet.MaxHeight.value);
        preferences.setString("ExportToJSON.cbJsonFormat", ui.gbSpriteSheet.cbJsonFormat.currentText);
        preferences.setBool("ExportToJSON.cbRemoveEmptyFrames", ui.gbSpriteSheet.cbRemoveEmptyFrames.checked);
        preferences.setBool("ExportToJSON.cbRemoveDuplicateFrames", ui.gbSpriteSheet.cbRemoveDuplicateFrames.checked);
        preferences.setBool("ExportToJSON.cbRemovePerframeWhitespace", ui.gbSpriteSheet.cbRemovePerframeWhitespace.checked);

        // Per resolution index, set name, width, height as .0.name, .0.width, .0.height ...
        preferences.setInt("ExportToJSON.resolutionCount", ui.gbResolution.tblResolution.rowCount);
        for (var i = 0; i < ui.gbResolution.tblResolution.rowCount; i++)
        {
          preferences.setString("ExportToJSON." + i + ".name", ui.gbResolution.tblResolution.item(i, 0).text());
          preferences.setInt("ExportToJSON." + i + ".width", ui.gbResolution.tblResolution.item(i, 1).text());
          preferences.setInt("ExportToJSON." + i + ".height", ui.gbResolution.tblResolution.item(i, 2).text());
        }
      }

      render.setRenderDisplay(ui.gbOptions.cbDisplay.currentText);

      // Get the display data for each frame in the sequence.
      // Show progress bar
      var progressDialog = new QProgressDialog(ui);
      {
        progressDialog.autoClose = true;
        progressDialog.open();
        progressDialog.setRange(0, frame.numberOf());
        progressDialog.setValue(0);
      }
      var renderedNodes = new NodeUtil.InputScan(ui.gbOptions.cbDisplay.currentText).toArray();
      var frameToDisplayData = [];
      var nodeAttributesToFrameToValue = [];
      if (checkedAndEnabled(ui.gbSpriteSheet.cbRemoveDuplicateFrames))
      {
        // Compose a list of data points that could change per-frame.
        nodeAttributesToFrameToValue = new Iter(renderedNodes)
          .flatMap(function (nodePath) {
            var attributes = NodeUtil.findModifiedAttributesForNode(nodePath, { precalculateBezier: true });
            return attributes
              .map(function (attr) {
                var path = nodePath + "." + attr.path;
                if ("constant" in attr)
                  return { path: path, value: attr.constant };
                else
                {
                  if (attr.curve.type == "PIVOT")
                    return { path: path, value: 0 };
                  if (attr.curve.type == "STREAM")
                    return { path: path, valueAtIndex: attr.curve.valueAtIndex };
                  else
                    throw translator.tr("Unsupported curve type: ") + attr.curve.type + " (" + path + ")";
                }
              });
          });
        for (var frameIdx = 0; frameIdx < frame.numberOf(); frameIdx++)
        {
          // Update progress bar.
          {
            progressDialog.setValue(frameIdx);
            var label = translator.tr("Scanning frame %1 of %2");
            label = label.split("%1").join(frameIdx);
            label = label.split("%2").join(frame.numberOf());
            progressDialog.setLabelText(label);
            if (progressDialog.wasCanceled)
            {
              throw translator.tr("Cancelled by user");
            }
          }
          frameToDisplayData[frameIdx] = nodeAttributesToFrameToValue.map(function (frameToValue) {
            if ("valueAtIndex" in frameToValue)
              return frameToValue.valueAtIndex[frameIdx];
            else
              return frameToValue.value;
          });
        }
      }
      else
      {
        nodeAttributesToFrameToValue = [{ path: "frame number", value: 0 }];
        for (var frameIdx = 0; frameIdx < frame.numberOf(); frameIdx++)
        {
          frameToDisplayData[frameIdx] = [frameIdx];
        }
      }
      progressDialog.close();

      for (var resolutionIdx = 0; resolutionIdx < ui.gbResolution.tblResolution.rowCount; resolutionIdx++)
      {
        var name = ui.gbResolution.tblResolution.item(resolutionIdx, 0).text();
        var width = ui.gbResolution.tblResolution.item(resolutionIdx, 1).text();
        var height = ui.gbResolution.tblResolution.item(resolutionIdx, 2).text();

        var spriteSheet = new SpriteSheet(ui, width, height, renderedNodes, frameToDisplayData, nodeAttributesToFrameToValue);

        if (!checkedAndEnabled(ui.gbOptions.cbUseSceneMarkers))
        {
          var sequence = [];
          for (var frameIdx = 0; frameIdx < frame.numberOf(); frameIdx++)
          {
            sequence.push(frameIdx);
          }
          spriteSheet.exportSheet(name, sequence);
        }
        else
        {
          var sceneMarkers = TimelineMarker.getAllMarkers();
          if (sceneMarkers.length == 0)
          {
            sceneMarkers.add({ frame: 1, name: "Default", length: frame.numberOf() });
            MessageLog.trace(translator.tr("No scene markers found, using default scene marker"));
          }          
          for (var sceneMarkerIdx = 0; sceneMarkerIdx < sceneMarkers.length; sceneMarkerIdx++)
          {
            var sceneMarker = sceneMarkers[sceneMarkerIdx];

            var sequence = [];
            for (var frameIdx = sceneMarker.frame; frameIdx < sceneMarker.frame + sceneMarker.length; frameIdx++)
            {
              sequence.push(frameIdx - 1);
            }
            spriteSheet.exportSheet(name + "_" + sceneMarker.name, sequence);
          }
        }
      }
    }
    catch (e)
    {
      MessageLog.trace(e);
      MessageBox.information(translator.tr("Error: ") + e);
    }
    finally
    {
      ui.close();
    }
  });

  ui.exec();
}

function SpriteSheet(ui, width, height, renderedNodes, frameToDisplayData, nodeAttributesToFrameToValue) {

  this.exportSheet = function (name, sequence) {

    // Convert sequence into lookups based on optimization settings.
    // Go through each frame in the sequence, check the data at the timeline frame index and see if it matches an existing frame.
    // If so, have sequence frame reference existing sprite.
    // Otherwise, create new sprite and add to spriteInfos.
    var sequenceFrameToSprite = [];
    var spriteInfos = [];


    // Start progress bar.
    var progressDialog = new QProgressDialog(ui);
    {
      progressDialog.autoClose = true;
      progressDialog.open();
      progressDialog.setRange(0, sequence.length);
      progressDialog.setValue(0);
    }

    try
    {
      for (var trialMaxWidth = 0; trialMaxWidth < sequence.length; trialMaxWidth++)
      {
        var frameIdx = sequence[trialMaxWidth];

        // update progress bar.
        {
          progressDialog.setValue(trialMaxWidth);
          var label = translator.tr("Optimizing frame %1 of %2");
          label = label.split("%1").join(frameIdx + 1);
          label = label.split("%2").join(sequence.length);
          progressDialog.setLabelText(label + (checkedAndEnabled(ui.gbOptions.cbUseSceneMarkers) ? " (" + name + ")" : ""));
          if (progressDialog.wasCanceled)
          {
            throw translator.tr("Cancelled by user");
          }
        }
        // Add -1 to sequenceFrameToSprite if the frame isn't visible.
        if (checkedAndEnabled(ui.gbSpriteSheet.cbRemoveEmptyFrames))
        {
          var visible = renderedNodes
            .filter(function (nodePath) { return node.type(nodePath) == "READ"; })
            .some(function (nodePath) { return NodeUtil.isReadNodeVisible(nodePath, frameIdx + 1); });
          if (!visible)
          {
            sequenceFrameToSprite.push(-1);
            MessageLog.trace("✕ frame " + (frameIdx + 1) + " skipped (invisible)");
            continue;
          }
        }

        // Check if the frame matches an existing sprite.
        var displayData = frameToDisplayData[frameIdx];
        var uniqueAttribute = null;
        var existingSpriteIdx = new Iter(spriteInfos).findIndex(function (spriteInfo) {
          return spriteInfo.displayData.every(function (value, idx) {
            var match = value == displayData[idx];
            if (!match)
            {
              uniqueAttribute = nodeAttributesToFrameToValue[idx].path;
            }
            return match;
          });
        });
        if (existingSpriteIdx == null)
        {
          // Create new sprite.
          existingSpriteIdx = spriteInfos.length;
          spriteInfos.push({ timelineFrame: frameIdx, displayData: displayData });
          if (uniqueAttribute != null)
          {
            MessageLog.trace("✓ Frame " + (frameIdx + 1) + " selected - " + uniqueAttribute + " is unique");
          }
          else
          {
            MessageLog.trace("✓ Frame " + (frameIdx + 1) + " selected (first)");
          }
        }
        else
        {
          MessageLog.trace("✕ Frame " + (frameIdx + 1) + " skipped - referencing existing frame " + (spriteInfos[existingSpriteIdx].timelineFrame + 1));
        }
        sequenceFrameToSprite.push(existingSpriteIdx);
      }
    }
    catch (e)
    {
      MessageLog.trace(e);
      MessageBox.information(translator.tr("Error: ") + e);
    }
    finally
    {
      progressDialog.close();
    }

    render.setResolution(width, height);

    // Start progress bar.
    var progressDialog = new QProgressDialog(ui);
    {
      progressDialog.autoClose = true;
      progressDialog.open();
      progressDialog.setRange(0, frame.numberOf());
      progressDialog.setValue(0);
    }

    try
    {
      // Render all sprites for all scene markers.
      var maxRect = null;
      var spriteToImage = [];
      for (var spriteIdx = 0; spriteIdx < spriteInfos.length; spriteIdx++)
      {
        var spriteInfo = spriteInfos[spriteIdx];
        var frameIdx = spriteInfo.timelineFrame + 1;
        // Update progress bar.
        {
          progressDialog.setValue(frameIdx);
          var label = translator.tr("Rendering frame %1 of %2");
          label = label.split("%1").join(frameIdx);
          label = label.split("%2").join(frame.numberOf());
          progressDialog.setLabelText(label + (checkedAndEnabled(ui.gbOptions.cbUseSceneMarkers) ? " (" + name + ")" : ""));
          if (progressDialog.wasCanceled)
          {
            throw translator.tr("Cancelled by user");
          }
        }
        // On frame rendered.
        function frameReady(_, frameCel) {
          // Aggregate the rect for all frames.
          {
            var allocatedRect = frameCel.allocatedRect();
            var rect = new QRect(allocatedRect[0], allocatedRect[1], allocatedRect[2], allocatedRect[3]);
            if (maxRect == null)
              maxRect = rect;
            else
              maxRect = maxRect.united(rect);
          }
          // Preserve a copy for later composition.
          {
            var imageFile = frameCel.imageFileAs(FileUtil.currentProjectPath() + "/Temp_ExportToJSON/" + frameIdx + ".png", "", "PNG4");
            var rect = frameCel.allocatedRect();
            spriteToImage.push({ path: imageFile.path(), rect: { x: rect[0], y: rect[1], width: rect[2], height: rect[3] } });
          }
        }
        // Actual render.
        render.frameReady.connect(frameReady);
        render.renderScene(frameIdx, frameIdx);
        render.frameReady.disconnect(frameReady);
      }
      var perSpriteRect = {
        x: maxRect.x(),
        y: maxRect.y(),
        width: maxRect.width(),
        height: maxRect.height()
      };

      // Export individual sprites into a new folder with the same name as the sheet.
      if (checkedAndEnabled(ui.gbSpriteSheet.cbIndividualSprites))
      {
        // Create folder to contain the images and json.
        {
          var dir = new QDir(ui.gbDirectory.savePath.text);
          dir.mkdir(name);
        }
        // Use painter to create a new image and crop to the sprite rect per-frame, save to dest folder.
        var painter = new QPainter();
        for (var trialMaxWidth = 0; trialMaxWidth < spriteToImage.length; trialMaxWidth++)
        {
          var src = spriteToImage[trialMaxWidth];
          var dest = ui.gbDirectory.savePath.text + "/" + ui.gbDirectory.saveName.text + "_" + name + "/" + trialMaxWidth + ".png";
          var image = new QImage(perSpriteRect.width, perSpriteRect.height, QImage.Format_ARGB32);
          painter.begin(image);
          painter.drawImage(0, 0, new QImage(src.path), perSpriteRect.x, perSpriteRect.y, perSpriteRect.width, perSpriteRect.height);
          painter.end();
          image.save(dest, "PNG");
          MessageLog.trace(translator.tr("Exported sprite ") + dest);
        }
      }
      // OR Compose all frames into a single image.
      else
      {
        // Each scene marker takes up its own paragraph of space.
        // A row is wrapped when the width exceeds the max width.
        function foreachImageInSheet(maxWidth, current, onIncreaseX, onIncreaseY) {
          var nextX = 0;
          var nextY = 0;
          var nextOffsetY = 0;
          spriteToImage.forEach(function (image) {
            var rect = checkedAndEnabled(ui.gbSpriteSheet.cbRemovePerframeWhitespace)
              ? image.rect
              : perSpriteRect;
            if (current)
              current(image, nextX, nextY, rect);
            nextX += rect.width;
            nextOffsetY = Math.max(nextOffsetY, rect.height);
            if (onIncreaseX)
              onIncreaseX(nextX);
            if (nextX + rect.width > maxWidth)
            {
              nextX = 0;
              nextY += nextOffsetY;
              nextOffsetY = 0;
              if (onIncreaseY)
                onIncreaseY(nextY);
            }
          });
          if (onIncreaseY)
            onIncreaseY(nextY + nextOffsetY);
        }

        // Calculate size of the image.
        var sheet = { width: 0, height: 0 };
        {
          // Brute force approach to find the smallest sheet size that fits all images.
          for (var trialMaxWidth = 0; trialMaxWidth < ui.gbSpriteSheet.MaxWidth.value; trialMaxWidth += 16)
          {
            sheet = { width: 0, height: 0 };
            foreachImageInSheet(
              trialMaxWidth,
              null,
              function (x) {
                sheet.width = Math.max(sheet.width, x);
              },
              function (y) {
                sheet.height = Math.max(sheet.height, y);
              }
            );
            // Quit once we found a set of dimensions that's approximately square.
            if (sheet.height < sheet.width && sheet.height <= ui.gbSpriteSheet.MaxHeight.value)
              break;
          }
          MessageLog.trace(translator.tr("Sheet size: ") + sheet.width + ", " + sheet.height);

          // Ensure that the height is not exceeded.
          if (sheet.height > ui.gbSpriteSheet.MaxHeight.value)
          {
            MessageLog.error(translator.tr("Sprite sheet height exceeds max height - please increase max width or height, or reduce the number of frames or resolution"));
            return;
          }
        }

        // Create the sheet image and painter.
        var sheetImage = new QImage(sheet.width, sheet.height, QImage.Format_ARGB32);
        var sprites = [];
        {
          var painter = new QPainter();
          painter.begin(sheetImage);

          // clear the image to transparent.
          {
            painter.setCompositionMode(QPainter.CompositionMode_Clear);
            painter.fillRect(sheetImage.rect(), Qt.transparent);
            painter.setCompositionMode(QPainter.CompositionMode_SourceOver);
          }

          // Crop image to perSpriteRect, and draw it at x, y.
          foreachImageInSheet(sheet.width, function (image, x, y, rect) {
            painter.drawImage(x, y, new QImage(image.path), rect.x, rect.y, rect.width, rect.height);
            sprites.push({
              sheet: {
                x: x,
                y: y,
              },
              source: rect,
            });
          });
        }

        var folderPath = ui.gbDirectory.savePath.text;

        // Unreal likes to import spritesheets in a folder with the same name as the sheet.
        if (ui.gbSpriteSheet.cbJsonFormat.currentText == "Unreal Paper 2D")
        {
          folderPath += "/" + ui.gbDirectory.saveName.text + "_" + name;

          // Ensure folder exists.
          {
            var dir = new QDir(folderPath);
            dir.mkdir(".");
          }
        }

        // Save the painted image.
        {
          var savePath = folderPath + "/" + ui.gbDirectory.saveName.text + "_" + name + ".png";
          sheetImage.save(savePath, "PNG");

          MessageLog.trace(translator.tr("Exported sheet") + " " + savePath);
        }

        // Save a json file beside it containing data per-frame.
        // This is a dropdown whose options are none, Unreal Paper 2D, or EaselJS
        var exportData = null;
        if (ui.gbSpriteSheet.cbJsonFormat.currentText == "Unreal Paper 2D")
        {
          exportData = exportUnrealPaper2D(ui, folderPath, name, sheet, sprites, sequenceFrameToSprite);
        }
        else if (ui.gbSpriteSheet.cbJsonFormat.currentText == "EaselJS")
        {
          exportData = exportEaselJS(ui, folderPath, name, sprites, sequenceFrameToSprite);
        }
        if (exportData != null)
        {
          var src = new QFile(exportData.savePath);
          src.open(QIODevice.WriteOnly);
          var out = new QTextStream(src);
          out.writeString(JSON.stringify(exportData.json, null, 2).replace(/\n/g, "\r\n"));
          src.close();

          MessageLog.trace(translator.tr("Exported") + " " + exportData.savePath);
        }
      }
    }
    catch (e)
    {
      MessageLog.trace(e);
      MessageBox.information(translator.tr("Error: ") + e);
    }
    finally
    {
      progressDialog.close();
    }
  }

  // Get number of digits from number
  function getDigits(number) {
    return number.toString().length;
  }

  // Add 0s to the beginning of a number so they are properly ordered by name.
  function folderOrderedNumber(number, length) {
    var str = number.toString();
    while (str.length < length)
    {
      str = "0" + str;
    }
    return str;
  }

  function exportEaselJS(ui, folderPath, name, sprites, sequenceFrameToSprite) {
    var savePath = folderPath + "/" + ui.gbDirectory.saveName.text + "_" + name + ".json";
    var json = {
      framerate: scene.getFrameRate(),
      images: [
        ui.gbDirectory.saveName.text + "_" + name + ".png"
      ],
      frames: [],
      animations: {},
    };
    sequenceFrameToSprite.forEach(function (spriteIdx) {
      var sprite = spriteIdx >= 0
        ? sprites[spriteIdx]
        : { source: { x: 0, y: 0, w: 0, h: 0 }, sheet: { x: 0, y: 0 } };
      json.frames.push([
        sprite.sheet.x,
        sprite.sheet.y,
        sprite.source.width,
        sprite.source.height,
        0,
        width / 2 - sprite.source.x,
        height / 2 - sprite.source.y,
      ]);
    });
    json.animations[name] = [
      0,
      sequenceFrameToSprite.length - 1
    ];
    return {
      savePath: savePath,
      json: json,
    }
  }

  function exportUnrealPaper2D(ui, folderPath, name, sheet, sprites, sequenceFrameToSprite) {
    var savePath = folderPath + "/" + ui.gbDirectory.saveName.text + "_" + name + ".paper2Dsprites";
    var json = {
      frames: {},
      meta: {
        app: "https://www.toonboom.com/products/harmony",
        target: "paper2D",
        image: ui.gbDirectory.saveName.text + "_" + name + ".png",
        format: "RGBA8888",
        size: {
          w: sheet.width,
          h: sheet.height,
        },
        scale: "1",
      },
    };
    var digits = getDigits(sequenceFrameToSprite.length - 1);
    sequenceFrameToSprite.forEach(function (spriteIdx, idx) {
      var sprite = spriteIdx >= 0
        ? sprites[spriteIdx]
        : { source: { x: 0, y: 0, w: 0, h: 0 }, sheet: { x: 0, y: 0 } };
      json.frames["Frame-" + folderOrderedNumber(idx, digits)] = {
        frame: {
          x: sprite.sheet.x,
          y: sprite.sheet.y,
          w: sprite.source.width,
          h: sprite.source.height,
        },
        rotated: false,
        trimmed: true,
        spriteSourceSize: {
          x: sprite.source.x,
          y: sprite.source.y,
          w: sprite.source.width,
          h: sprite.source.height,
        },
        sourceSize: {
          w: width,
          h: height,
        },
      };
    });
    return {
      savePath: savePath,
      json: json,
    }
  }
}

showUI();
