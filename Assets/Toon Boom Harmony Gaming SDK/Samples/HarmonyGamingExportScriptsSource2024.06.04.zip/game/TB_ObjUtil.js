/*
 * Copyright Toon Boom Animation Inc - 2022
 */

/**
 * @template {Object} T
 * @param obj {T}
 * @returns {Array<keyof T>}
 */
exports.keys = function (obj) {
  return /**@type any*/(Object.keys(obj));
}

/**
 * @template {Object} T
 * @param {T} obj
 * @returns {Array<{ key: keyof T, value: T[keyof T] }>}
 */
exports.entries = function (obj) {
  var theKeys = exports.keys(obj);
  return theKeys.map(function (key) { return { key: key, value: obj[key] }; });
}

/**
 * @template {Object} T
 * @param {T} obj
 * @returns {Array<T[keyof T]>}
 */
exports.values = function (obj) {
  var theKeys = exports.keys(obj);
  return theKeys.map(function (key) { return obj[key]; });
}

/**
 * @template {string | number} T, U
 * @param {Array<{ key: T, value: U }>} entries
 * @returns {Record<T, U>}
 */
exports.fromEntries = function (entries) {
  var result = /**@type Record<T, U>*/({});
  entries.forEach(function (entry) { result[entry.key] = entry.value; });
  return result;
}

/**
 * @template {Object} T
 * @template {Object} U
 * @param {T} first
 * @param {U} second
 * @returns {T & U}
 * Merge the fields of two objects together into a new object.
 * Emulates { ...first, ...second } from ES6 syntax ---
 * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Spread_syntax
 */
exports.merge = function (first, second) {
  const firstEntries = /**@type any*/(exports.entries(first));
  const secondEntries = /**@type any*/(exports.entries(second));
  return /**@type any*/(exports.fromEntries(firstEntries.concat(secondEntries)));
}