/*
 * Copyright Toon Boom Animation Inc - 2022
 */

type NodeType = "COMPOSITE" | "WRITE" | "DISPLAY" |
  "MULTIPORT" | "MULTIPORT_IN" | "MULTIPORT_OUT" | "DeformationSwitchModule" |
  "AutoFoldModule" | "AutoMuscleModule" | "DeformationScaleModule" | "KinematicOutputModule" |
  "DeformationUniformScaleModule" | "DeformationWaveModule" | "ArticulationModule" |
  "OffsetModule" | "CurveModule" | "READ" | "CUTTER" | "CUTTER-MASK" | "READ" | "PEG" | "BoneModule" |
  "BendyBoneModule" | "GameBoneModule" | "DeformationCompositeModule" | "DeformationRootModule" | "GROUP" |
  "CAMERA";

/** Include neighboring script definitions into this file's global space */
declare function include(script: string): void;

declare namespace frame {
  function numberOf(): number;
  function current(): number;
  function insert(atFrame: number, nbFrames: number, options: QScriptValue = {}): void;
}

declare namespace scene {
  function currentScene(): string;
  function saveAll(): void;
  function beginUndoRedoAccum(commandName: string): void;
  function endUndoRedoAccum(): void;
  function undo(depth?: number): void;
  function clearRedo(): void;
  function redo(depth?: number): void;
  function cancelUndoRedoAccum(): void;
  function currentProjectPathRemapped(): string;
  function currentVersionName(): string;
  function unitsAspectRatioX(): number;
  function unitsAspectRatioY(): number;
  function numberOfUnitsX(): number;
  function numberOfUnitsY(): number;
  function currentResolutionX(): number;
  function currentResolutionY(): number;
  function getFrameRate(): number;
  function toOGL(point: Point3d): Point3d;
  function toOGL(point: Vector2d): Vector2d;
  function fromOGL(point: Point3d): Point3d;
  function fromOGL(point: Vector2d): Vector2d;
  function metadatas(): Array<{
    name: string;
    value: string;
  }>;
  function getDefaultDisplay(): NodePath | "Unconnected_Display";
  function isDirty(): boolean;
  function currentContainerPath(): string;
  function metadata(name: string): { name: string, value: string } | undefined;
  function setMetadata(params: { name: string, value: string }): void;
}

declare namespace preferences {
  function getString(name: string, defaultValue: string): string;
  function getBool(name: string, defaultValue: boolean): boolean;
  function getInt(name: string, defaultValue: number): number;
  function getDouble(name: string, defaultValue: number): number;
  function setString(name: string, value: string): void;
  function setBool(name: string, value: boolean): void;
  function setInt(name: string, value: number): void;
  function setDouble(name: string, value: number): void;
}

declare namespace deformation {
  function lastRestMatrix(node: string): Matrix4x4;
  function nextRestMatrix(node: string): Matrix4x4;
  function lastDeformMatrix(node: string, frame: number): Matrix4x4;
  function nextDeformMatrix(node: string, frame: number): Matrix4x4;
}

/** Translate messages from English in to language localized for interface */
declare namespace translator {
  /**
   * Translate message to localized language in interface
   * @param message Message in English
   */
  function tr(message: string): string;
}

declare namespace selection {
  function numberOfNodesSelected(): number;
  function selectedNode(index: number): NodePath;
  function clearSelection(): void;
  function addNodeToSelection(node: string): void;
}
declare namespace Action {
  function perform(funcToCall: "onActionSaveEverything()");
  function performForEach(funcToCall: "onActionFocusOnSelectionNV()", target: "Node View");
}
declare namespace node {
  /**
    * @param node The path of the node
    * @returns the node type
    */
  function type(node: NodePath): NodeType;
  function linkedColumn(node: NodePath, attribute: string): string;
  function getTextAttr(node: NodePath, atFrame: number, attrName: string): string;
  function setTextAttr(node: NodePath, attrName: string, atFrame: number, value: string): boolean;
  function getEnable(node: NodePath): boolean;
  function getAttr(node: NodePath, atFrame: number, attrName: string): Attribute?;
  function getAttrList(node: NodePath, atFrame: 1, attrName?: string): Attribute[];
  function getName(node: NodePath): string;
  function rename(node: NodePath, name: string): void;
  function srcNode(node: NodePath, portIndex: number): NodePath;
  function srcNodeInfo(node: NodePath, portIndex: number): { node: NodePath, port: number, link: number };
  function dstNode(node: NodePath, portIndex: number, linkIndex: number): NodePath;
  function dstNodeInfo(node: NodePath, portIndex: number, linkIndex: number): { node: NodePath, port: number };
  function flatSrcNode(node: NodePath, portIndex: number): NodePath;
  function isGroup(node: NodePath): boolean;
  function noNode(): string;
  function numberOfInputPorts(node: NodePath): number;
  function numberOfOutputPorts(node: NodePath): number;
  function numberOfOutputLinks(node: NodePath, portIndex: number): number;
  function subNode(node: NodePath, nodeIndex: number): NodePath;
  function subNodes(node: NodePath): NodePath[];
  function parentNode(node: NodePath): NodePath;
  function coordX(node: NodePath): number;
  function coordY(node: NodePath): number;
  function coordZ(node: NodePath): number;
  function add(node: NodePath, name: string, type: NodeType, x: number, y: number, z: number): NodePath;
  function deleteNode(node: NodePath, deleteTimedValues?: boolean, deleteElements?: boolean): boolean;
  function link(srcNode: NodePath, srcPort: number, dstNode: NodePath, dstPort: number): void;
  function unlink(srcNode: NodePath, srcPort: number): void;
  function getElementId(node: NodePath): number;
  function getPivot(node: NodePath, frame: number): Point3d;
  function getMatrix(node: NodePath, frame: number): Matrix4x4;
  function setAsDefaultCamera(camera: string): void;
  function root(): NodePath;
  function numberOfSubNodes(node: NodePath): number;
  function setColor(node: NodePath, color: ColorRGBA): void;
}

declare namespace WriteNode {
  function startFrame(): number;
  function endFrame(): number;
}

declare class Color {
  name: string;
  id: string;
  isValid: boolean;
  isTexture: boolean;
  colorType: number;
  colorData: { r: number; g: number; b: number; a: number; } | [{ r: number; g: number; b: number; a: number; }, { r: number; g: number; b: number; a: number; }];
}

declare class ColorRGBA extends BaseColor {
  constructor();
  constructor(r: number, g: number, b: number, a: number);
}

declare namespace render {
  function setBgColor(color: ColorRGBA): void;
  function setResolution(width: number, height: number): void;
  function setAutoThumbnailCropping(setCropping: boolean): void;
  function setWhiteBackground(setBackgreound: boolean): void;
  function setRenderDisplay(displayModuleName: string): void;
  function renderSceneAll(): void;
  function renderScene(fromFrame: number, toFrame: number): void;
  type FrameCel = {
    imageFile: (filePath: string) => void,
    imageFileAs: (filePath: string, format: string, option: string) => void,
    rect: () => [number, number, number, number],
    allocatedRect: () => [number, number, number, number],
  };
  type Callback = (frame: number, frameCel: FrameCel) => void;
  const frameReady: {
    connect: (callback: Callback) => void;
    disconnect: (callback: Callback) => void;
  }
}

declare type SoundSequence = {
  startFrame: number,
  stopFrame: number,
  name: string,
  filename: string,
}

declare namespace column {
  function getElementIdOfDrawing(column: string): number;
  function type(column: string): "DRAWING" | "SOUND" | "3DPATH" | "BEZIER" | "EASE" | "EXPR" | "TIMING" | "QUATERNIONPATH" | "ANNOTATION";
  function velocityType(column: string): "BEZIER" | "EASE";
  function numberOf(): number;
  function getName(columnIdx: number): string;
  function soundColumn(column: string): { sequences: () => SoundSequence[] };
  function getEntry(column: string, subColumn: number, atFrame: number): string;
  function setEntry(column: string, subColumn: number, atFrame: number, value: string): void;
  function getDrawingTimings(column: string): number[];
}

declare namespace element {
  function getNameById(id: number): string;
}

declare namespace func {
  function convertToSeparate(columnName: string, conversionAlgo: "TRANSFORM_MATRIX" | "BEZIER_FITTER"): string[] | undefined;
  function holdStartFrame(columnName: string): number;
  function holdStopFrame(columnName: string): number;
  function holdStep(columnName: string): number;
  function setEntry(columnName: string, subColumn: number, AtFrame: number, value: string): boolean;
  function getEntry(columnName: string, subColumn: number, AtFrame: number): string;
  function setKeyFrame(columnName: string, AtFrame: number): boolean;
  function clearKeyFrame(columnName: string, AtFrame: number): boolean;
  function numberOfPoints(columnName: string): number;
  function functionType(columnName: string): string;
  function pointX(columnName: string, point: number): number;
  function pointY(columnName: string, point: number): number;
  function pointConstSeg(columnName: string, point: number): boolean;
  function pointContinuity(columnName: string, point: number): string;
  function pointHandleLeftX(columnName: string, point: number): number;
  function pointHandleLeftY(columnName: string, point: number): number;
  function pointHandleRightX(columnName: string, point: number): number;
  function pointHandleRightY(columnName: string, point: number): number;
  function pointEaseIn(columnName: string, point: number): number;
  function angleEaseIn(columnName: string, point: number): number;
  function pointEaseOut(columnName: string, point: number): number;
  function angleEaseOut(columnName: string, point: number): number;
  function numberOfPointsPath3d(columnName: string): number;
  function pointXPath3d(columnName: string, point: number): number;
  function pointYPath3d(columnName: string, point: number): number;
  function pointZPath3d(columnName: string, point: number): number;
  function pointTensionPath3d(columnName: string, point: number): number;
  function pointContinuityPath3d(columnName: string, point: number): number;
  function pointBiasPath3d(columnName: string, point: number): number;
  function pointLockedAtFrame(columnName: string, point: number): number;
  function setHoldStartFrame(columnName: string, start: number): boolean;
  function setHoldStopFrame(columnName: string, stop: number): boolean;
  function setHoldStep(columnName: string, step: number): boolean;
  function setBezierPoint(columnName: string,
    frame: number, y: number,
    handleLeftX: number, handleLeftY: number,
    handleRightX: number, handleRightY: number,
    constSeg: boolean, continuity: string): boolean;
  function setVeloBasePoint(columnName: string,
    frame: number, y: number): void;
  function setEasePoint(columnName: string,
    frame: number, y: number,
    easeIn: number, angleEaseIn: number,
    easeOut: number, angleEaseOut: number,
    constSeg: boolean, continuity: string): boolean;
  function addKeyFramePath3d(columnName: string, frame: number,
    x: number, y: number, z: number,
    tension: number, continuity: number, bias: number): boolean;
  function addCtrlPointAfterPath3d(columnName: string, point: number,
    x: number, y: number, z: number,
    tension: number, continuity: number, bias: number): void;
  function removePointPath3d(columnName: string, point: number): boolean;
  function setPointPath3d(columnName: string, point: number,
    x: number, y: number, z: number,
    tension: number, continuity: number, bias: number): boolean;
  function setPath3dPointConstantSegment(columnName: string, point: number, constant: boolean): boolean;
  function setPath3dPointConstantSegmentForFrame(columnName: string, point: number, constant: boolean): boolean;
}


declare namespace MessageLog {
  /**
   * Display message to the MessageLog window
   * @param message Message to display in the MessageLog window
   */
  function trace(...message: (string | number | Object)[]): void;
}

declare namespace System {
  function println(message: string): void;
}

declare namespace MessageBox {
  function information(message: string, ...buttons: MessageBox[]): MessageBox;
  function critical(message: string, ...buttons: MessageBox[]): MessageBox;
  function warning(message: string, ...buttons: MessageBox[]): MessageBox;
}

declare enum MessageBox {
  Ok,
  Cancel,
  Yes,
  No,
  NoButton,
}

declare namespace Timeline {
  const numLayers: number;
  /**
   * @returns path of the node
   */
  function layerToNode(layer: number): sting;
}

declare class Attribute {
  keyword(): string;
  intValue(): number;
  boolValue(): boolean;
  textValue(): string;
  keyword(): string;
  fullKeyword(): string;
  pos3dValue(): Point3d;
  getSubAttributes(): Attribute[] | null;
}

declare class PermanentFile {
  constructor(path: string): void;
  copy(dest: PermanentFile): void;
}

declare namespace FileDialog {
  function getExistingDirectory(exportDir: string, message: string): void;
  function getOpenFileName(fileType: string, message: string): void;
}

declare class File {
  constructor(filename: string): void;
  open(access: number): void;
  read(): string;
  write(data: string): void;
  close(): void;
  exists: boolean;
}

declare namespace FileAccess {
  const ReadOnly: number;
  const WriteOnly: number;
  const ReadWrite: number;
  const Append: number;
  const Truncate: number;
  const Translate: number;
}

declare class Dir {
  path: string;
  rmdirs(): void;
}

declare class QDir {
  constructor(): void;
  constructor(path: string): void;
  setPath(path: string): void;
  setNameFilters(nameFilters: string[]): void;
  mkdir(folderName: string): void;
  exists(): boolean;
  setFilter(FilterEnum: number): void;
  entryList(): string[];
  absolutePath(): string;
  relativeFilePath(path: string): string;
}

declare namespace specialFolders {
  const resource: string;
  const bin: string;
}

declare namespace about {
  const windowArch: boolean;
  const macArch: boolean;
  function isMacArch(): boolean;
  function isLinuxArch(): boolean;
  function isWindowsArch(): boolean;
}

declare class Process2 {
  constructor(process: string, ...args: string[]): void;
  launch(): number;
  launchAndDetach(): void;
  commandLine(): string;
  errorCode(): number;
}

declare type PaletteList = {
  movePaletteUp: (id: string) => boolean;
  getPaletteByIndex: (idx: number) => Palette;
  getPaletteById: (id: string) => Palette;
  numPalettes: number;
  elementId: number;
  createPalette: (path: string, insertIndex: number) => Palette;
  removePalette: (path: string) => boolean;
  removePaletteById: (id: string) => boolean;
};

declare type Marker = {
  name: string;
  frame: number;
  length: number;
  color: number | string;
  notes: string;
};
declare namespace TimelineMarker {
  function getAllMarkers(): Marker[];
  function getMarkersAtFrame(frame: number): Marker[];
}

declare type Palette = {
  id: string
  nColors: number;
  elementId: number;
  getName(): string;
  getColorByIndex(index: number): Color;
  containsUsedColors(colorList: string[]): boolean;
  isTexturePalette(): boolean;
  cloneColor(color: Color): Color;
};

declare namespace PaletteObjectManager {
  function getScenePaletteList(): PaletteList;
  function getNumPaletteLists(): number;
  function getPaletteListByIndex(index: number): PaletteList;
}

declare type DrawingKey = { __unkown__: true };

declare namespace Drawing {
  type Request = { drawing: { node: NodePath, frame: number }, art: 0 | 1 | 2 | 3 };
  function numberOf(elementId: number): number;
  function name(elementId: number, drawingIndex: number): string;
  function Key(props: { elementId: number, layer: string, exposure: string }): DrawingKey;
  function filename(elementId: number, nameOrExposure: string | number): string;
  declare namespace query {
    function getStrokes(request: Request): { layers: Array<any>, drawing: Request };
    function getNumberOfLayers(request: Request): number;
  };
}

declare namespace DrawingTools {
  function getDrawingUsedColors(drawingKey: DrawingKey): string[];
}

declare function GenerateTextureAtlas(
  textureFolder: string,
  rootFolder: string,
  resX: number,
  resY: number,
  maxSpriteSheet: number,
  riggingName: string,
  fixedResolution: boolean,
  resType: "POT" | "NPOT" | "ANY",
  spriteResName: string,
  reuseFramesThreshold: number): string;

declare class Matrix4x4 {
  translate(x: number, y: number, z: number): void;
  translate(point: Point3d): void;
  rotateDegrees(degrees: number, axis: Vector3d): void;
  getInverse(): Matrix4x4;
  multiply(other: Matrix4x4): Matrix4x4;
  multiply(point: Point3d): Point3d;
  clear(): void;
  multiplyEq(other: Matrix4x4): Matrix4x4;
  extractRotation(pivot: Point3d, force3d: boolean): Point3d;
  extractPosition(pivot: Point3d, force3d: boolean): Point3d;
  extractScale(pivot: Point3d, force3d: boolean): Point3d;
  extractSkew(pivot: Point3d): number;
  value(row: number, column: number): number;
  m00: number;
  m01: number;
  m02: number;
  m03: number;
  m10: number;
  m11: number;
  m12: number;
  m13: number;
  m20: number;
  m21: number;
  m22: number;
  m23: number;
  m30: number;
  m31: number;
  m32: number;
  m33: number;
}

declare function Utransform(...args: (string | number)[]): string;
declare namespace Utransform {
  const resetPalettes: function(): void | undefined;
}

declare namespace CELIO {
  function getInformation(fileName: string): { width: number, height: number };
}

declare class Vector3d {
  constructor(x: number, y: number, z: number): void;
  constructor(): void;
  x: number;
  y: number;
  z: number;
  radianAngle(): number;
  length(): number;
}

declare class Point3d {
  constructor(x: number, y: number, z: number): void;
  constructor(): void;
  x: number;
  y: number;
  z: number;
  distance(other: Point3d): number;
  minus(other: Point3d): Vector3d;
}

declare class Vector2d {
  constructor(x: number, y: number): void;
  constructor(): void;
  x: number;
  y: number;
  rotate(radians: number): void;
  radianAngle(): number;
  length(): number;
}

declare class Point2d {
  constructor(x: number, y: number): void;
  constructor(): void;
  x: number;
  y: number;
  distance(other: Point2d): number;
  minus(other: Point2d): Vector2d;
}

declare namespace QCoreApplication {
  function processEvents(): void;
}

declare class QFileInfo {
  constructor(path: string): void;
  exists(): boolean;
  isDir(): boolean;
  isFile(): boolean;
  absolutePath(): string;
  completeBaseName(): string;
}

declare class QColor {
  constructor(r: number, g: number, b: number): void;
}
declare class QListWidgetItem {
  constructor(text: string);
  setText(text: string): void;
  setForeground(color: QColor): void;
  flags(): number;
  setFlags(flag: number): void;
  setCheckState(checkstate: nuomber): void;
  checkState(): number;
}

declare class QCheckBox {
  constructor(text: string): void;
  checked: boolean;
  setChecked(checked: boolean): void;
}

declare namespace Qt {
  var ItemIsEnabled: number;
  var ItemIsUserCheckable: number;
  var Checked: number;
  var Unchecked: number;
}

declare namespace QDir {
  const Files: number;
  const AllDirs: number;
}

declare class QFile {
  constructor(filename: string): void;
  exists(): boolean;
  remove(): void;
  rename(path: string): boolean;
}

declare namespace QFile {
  function copy(fromPath: string, toPath: string): void;
}

declare class QDomAttribute {
  nodeName(): string;
  nodeValue(): string;
}

declare class QDomAttributes {
  length(): number;
  item(idx: number): QDomAttribute;
  namedItem(name: string): QDomAttribute;
}

declare class QDomElement {
  nodeName?(): string;
  appendChild(element: QDomElement): void;
  nextSiblingElement(): QDomElement | null;
  hasChildNodes(): boolean;
  firstChildElement(): QDomElement | null;
  removeChild(element: QDomElement): void;
  hasAttributes(): boolean;
  attribute(key: string, defaultValue?: string): string;
  attributes(): QDomAttributes;
  setAttribute(key: string, value: string | number): void;
  tagName(): string;
  toString(): string;
}

declare class QDomDocument {
  nodeName(): string;
  createElement(tag: string): QDomElement;
  setContent(content: string): void;
  hasChildNodes(): boolean;
  firstChildElement(): QDomElement | null;
  appendChild(element: QDomElement): void;
}

declare class QTableWidgetItem {
  constructor(name: string): void;
  text(): string;
}

declare class QProgressDialog {
  setLabelText(message: string): void;
  setRange(start: number, end: number): void;
  setValue(value: number): void;
  open(): void;
  show(): void;
  close(): void;
  modal: boolean;
  autoClose: boolean;
  wasCanceled: boolean;
}

declare class QEvent<T = undefined> {
  connect(func: (value: T) => void): void;
  connect(bindThis: any, func: () => void): void;
}

declare type NestedUIMember = {
  [key: string]: NestedUIMember;
} & {
  signalBlocked: boolean;
  blockSignals(shouldBlock: boolean): void;

  checked: boolean;
  setChecked(checked: boolean): void;

  text: string;
  setText(text: string): void;
  findText(text: string): number;

  value: number;
  setValue(value: number): void;

  currentText: string;
  currentIndex: number;
  setCurrentIndex(index: number): void;

  layout(): NestedUIMember;

  widget(): NestedUIMember;
  widget(index: number): NestedUIMember;
  addWidget(widget: QCheckBox, row?: number, column?: number);

  clear(): void;
  addItem(item: QListWidgetItem): void;

  rowCount: number;
  item(row: number): QListWidgetItem;
  item(row: number, column: number): QTableWidgetItem | undefined;
  itemAt(index: number): NestedUIMember;
  currentRow(): number;
  setItem(row: number, column: number, item: QTableWidgetItem): void;
  setCurrentCell(row: number, column: number): void;
  setCurrentItem(itemName: QTableWidgetItem): void;
  insertRow(row: number): void;
  removeRow(row: number): void;

  ["valueChanged(double)"]: QEvent<number>;
  ["currentIndexChanged(int)"]: QEvent<number>;
  valueChanged: QEvent<any>;
  editingFinished: QEvent;
  clicked: QEvent;
  hide(): void;
  setEnabled(enabled: boolean): void;
}

declare type UIDialog = NestedUIMember & {
  exec(): boolean;
  close(): void;
  setEnabled(enabled: boolean): void;
  windowTitle: string;
}

declare class Dialog {
  title: string;
  width: number;
  okButtonText: string;
  exec(): boolean;
};

declare namespace UiLoader {
  function setSvgIcon(button: NestedUIMember, path: string): void;
  function load(props: { uiFile: string, parent: UIDialog, folder: string }): UIDialog;
  function load(uiFile: string): UIDialog;
}