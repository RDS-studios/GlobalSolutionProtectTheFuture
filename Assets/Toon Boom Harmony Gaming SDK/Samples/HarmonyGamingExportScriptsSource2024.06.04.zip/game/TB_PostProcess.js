/*
 * Copyright Toon Boom Animation Inc - 2022
 */

var NodeUtil = require("./TB_NodeUtil.js");

/**
 * Starting from a maintainable/Harmony-based naming/indexing/scaling to the novel Game API format for naming/indexing/scaling  
 * @param {number} unitScale
 */
exports.PostProcess = function (unitScale) {

  this.unitScale = unitScale;

  /**
   * @param {NodePath} nodePath
   * @param {string | number} spriteIdx
   * @param {Record<string, boolean>} existingSpritePaths
   */
  this.nodePathAndSprite = function (nodePath, spriteIdx, existingSpritePaths) {
    var transformedNodePath = nodePath.split("/").slice(-1).concat(spriteIdx.toString()).join("_");
    var candidate = transformedNodePath;
    // Because we are saving these sprites out to the file system, we have to ensure we don't have any case-insensitive collisions.
    {
      for (var i = 1; existingSpritePaths[candidate.toLowerCase()]; i++)
      {
        candidate = transformedNodePath + i;
      }
      existingSpritePaths[candidate.toLowerCase()] = true;
    }
    return /**@type SpritePath*/(candidate + ".png");
  }

  /**
   * @param {string} nodePath
   */
  this.safeNodePath = function (nodePath) {
    return /**@type NodePath*/(nodePath);
  }

  /**
   * @param {string} animationName
   */
  this.safeAnimationName = function (animationName) {
    return /**@type AnimationName*/("anim." + animationName.toLowerCase());
  }

  /**
   * @param {string} skinName
   */
  this.safeSkinName = function (skinName) {
    return /**@type SkinName*/("skin." + skinName);
  }

  /**
   * @param {SkinName} skinName
   */
  this.skinName = function (skinName) {
    if (skinName == "none")
    {
      return skinName;
    };
    return skinName.split(".").slice(1).join(".");
  }

  /**
   * @param {number} index
   */
  this.indexToDrwID = function (index) {
    return index + 1;
  }
  
  /**
   * @param {UniqueNodePath} rootNodePath
   */
  this.skeleton = function (rootNodePath) {
    return NodeUtil.nodePath(NodeUtil.decomposeUniqueNode(rootNodePath).nodePath);
  }

  /**
   * @param {NodePath} nodePath
   * @param {string} attrName
   */
  this.deformColumnName = function (nodePath, attrName) {
    return attrName.split(".").join("-").toUpperCase() + "-" + NodeUtil.nodePath(nodePath);
  }

  /**
   * Map the uppercase harmony attribute path to an accepted lowercase variation for the Gaming SDK
   * @param {string} path
   */
  this.attributePath = function (path) {
    /**@type {Record<string, boolean>}*/
    var subAttrToRemove = {
      "3DPATH": true,
    }
    return path
      .split(".")
      .filter(function (subAttr) { return !subAttrToRemove[subAttr]; })
      .join(".")
      .toLowerCase();
  }

  /**
   * Map the uppercase harmony column type to an accepted lowercase variation for the Gaming SDK
   * @type {Record<string, string | null>}
   */
  this.columnTypeToTimedValue = {
    "3DPATH": "catmull",
  }

  /**
   * Map local node type for parsing to accepted xml tag in skeleton.
   * Anchors are treated as pegs.
   * @param {NodePath} nodePath
   * @param {GameNodeTag} nodeTag
   * @param {Lookup<NodePath, true>} anchors
   */
  this.nodeTypeToSkeletonTag = function (nodePath, nodeTag, anchors) {
    if (nodeTag == "bake")
    {
      return "read";
    }
    if (anchors[nodePath])
    {
      return "peg";
    }
    return nodeTag;
  }


  /**
   * Only some attribute transformations are supported in the Game API
   * Taken from TR_Utils.cpp
   * @type {Lookup<string, true>}
   */
  this.attributeWhitelist = {
    "SCALE.X": true,
    "SCALE.Y": true,
    "SCALE.XY": true,
    "ROTATION.ANGLEZ": true,
    "ROTATION.Z": true,
    "SKEW": true,
    "POSITION.3DPATH": true,
    "OFFSET.3DPATH": true,
    "OFFSET": true,
    "POSITION.X": true,
    "OFFSET.X": true,
    "POSITION.Y": true,
    "OFFSET.Y": true,
    "POSITION.Z": true,
    "OFFSET.Z": true,
    "VELOCITY": true,
    "PIVOT": true,
    "OPACITY": true,
  };

  this.xScale = (scene.unitsAspectRatioX() / scene.unitsAspectRatioY()) * (scene.numberOfUnitsX() / scene.numberOfUnitsY());
  this.zScale = 1;//scene.toOGL(new Point3d(0, 0, 1)).z;

  /**
   * What values from attributes should be scaled by when outputting to API format
   * @type {Lookup<string, number>}
   */
  var attributeValueScales = {
    "ROTATION.ANGLEZ": 3.14159 / 180.0,
    "ROTATION.Z": 3.14159 / 180.0,
    "OPACITY": 1 / 100.0,
    "SCALE.X": 1,
    "SCALE.Y": 1,
    "SCALE.Z": 1,
    "POSITION.X": this.unitScale * this.xScale,
    "POSITION.Y": this.unitScale,
    "POSITION.Z": this.zScale,
    "POSITION.3DPATH.X": this.unitScale * this.xScale,
    "POSITION.3DPATH.Y": this.unitScale,
    "POSITION.3DPATH.Z": this.zScale,
    "OFFSET.X": this.unitScale * this.xScale,
    "OFFSET.Y": this.unitScale,
    "OFFSET.Z": this.zScale,
    "OFFSET.3DPATH.X": this.unitScale * this.xScale,
    "OFFSET.3DPATH.Y": this.unitScale,
    "OFFSET.3DPATH.Z": this.zScale,

    // Generated attributes.
    "deform.rotation.z": 3.14159 / 180.0,
    "deform.offset.x": this.unitScale * this.xScale,
    "deform.offset.y": this.unitScale,
    "deform.length": this.unitScale * this.xScale,
    "deform.radius": this.unitScale * this.xScale,
    "rest.rotation.z": 3.14159 / 180.0,
    "rest.offset.x": this.unitScale * this.xScale,
    "rest.offset.y": this.unitScale,
    "rest.length": this.unitScale * this.xScale,
    "rest.radius": this.unitScale * this.xScale,
  };

  /**
   * Special scaling when you're the root / you're not scaled by the root (peg-less deformations)
   * @type {Lookup<string, { x: number, y: number, z: number }>}
   */
  var attribute3DValueScales = {
    "PIVOT": { x: this.unitScale * this.xScale, y: this.unitScale, z: this.zScale },
    "POSITION.3DPATH": { x: this.unitScale * this.xScale, y: this.unitScale, z: this.zScale },
    "OFFSET.3DPATH": { x: this.unitScale * this.xScale, y: this.unitScale, z: this.zScale },

    // Generated attributes.
    "deform.offset.3DPATH": { x: this.unitScale * this.xScale, y: this.unitScale, z: this.zScale },
    "rest.offset.3DPATH": { x: this.unitScale * this.xScale, y: this.unitScale, z: this.zScale },
  };

  // var dejitterScale = 100000;//Math.pow(2, 12);

  /**
   * @param {number} value
   */
  function dejitter(value) {
    return value;//Math.round(value * dejitterScale) / dejitterScale;
  }

  /**
   * @param {string} attrPath
   * @param {number} valueContainer
   */
  this.scaleConstant = function (attrPath, valueContainer) {
    var customScale = (attributeValueScales[attrPath] || 1);
    return dejitter(valueContainer * customScale);
  }

  /**
   * @param {string} attrPath
   * @param {PivotPoint} valueContainer
   */
  this.scalePivot = function (attrPath, valueContainer) {
    var customScale3D = attribute3DValueScales[attrPath] || { x: 1, y: 1, z: 1 };
    return /**@type PivotPoint*/({
      start: valueContainer.start,
      x: dejitter(valueContainer.x * customScale3D.x),
      y: dejitter(valueContainer.y * customScale3D.y),
      z: dejitter(valueContainer.z * customScale3D.z),
    });
  }

  /**
   * @param {string} attrPath
   * @param {Curve | Stream} curve
   * @returns {Curve | Stream}
   */
  this.scaleCurve = function (attrPath, curve) {
    switch (curve.type)
    {
      case "PIVOT":
        var customScale3D = (attribute3DValueScales["PIVOT"] || { x: 1, y: 1, z: 1 });
        return {
          type: curve.type,
          points: curve.points.map(function (pivot) {
            return {
              start: pivot.start,
              x: dejitter(pivot.x * customScale3D.x),
              y: dejitter(pivot.y * customScale3D.y),
              z: dejitter(pivot.z * customScale3D.z),
            };
          }),
        };
      case "STREAM":
        var customScale = (attributeValueScales[attrPath] || 1);
        return {
          type: curve.type,
          valueAtIndex: curve.valueAtIndex.map(function (value) {
            return value * customScale;
          }),
        };
      case "LINEAR":
        var customScale = (attributeValueScales[attrPath] || 1);
        return {
          type: curve.type,
          points: curve.points.map(function (point) {
            return /**@type LinearPoint*/({
              x: dejitter(point.x + 1),
              y: dejitter(point.y * customScale),
            });
          }),
        };
      case "BEZIER":
        var customScale = (attributeValueScales[attrPath] || 1);
        return {
          type: curve.type,
          points: curve.points.map(function (point) {
            return /**@type BezierPoint*/({
              x: dejitter(point.x + 1),
              y: dejitter(point.y * customScale),
              lx: dejitter(point.lx + 1),
              ly: dejitter(point.ly * customScale),
              rx: dejitter(point.rx + 1),
              ry: dejitter(point.ry * customScale),
              constSeg: point.constSeg,
            });
          }),
        };
      case "3DPATH":
        var customScale3D = (attribute3DValueScales[attrPath] || { x: 1, y: 1, z: 1 });
        return {
          type: curve.type,
          points: curve.points.map(function (point) {
            return /**@type PathPoint*/({
              lockedInTime: dejitter(point.lockedInTime + 1),
              x: dejitter(point.x * customScale3D.x),
              y: dejitter(point.y * customScale3D.y),
              z: dejitter(point.z * customScale3D.z),
              tension: point.tension,
              continuity: point.continuity,
              bias: point.bias,
            });
          }),
        };
    }
  }

  /**
   * @type {Record<string, number>}
   */
  var attributeDefaultValues = {
    "ROTATION.ANGLEZ": 0,
    "ROTATION.Z": 0,
    "SKEW": 0,
    "OPACITY": 1,
    "SCALE.X": 1,
    "SCALE.Y": 1,
    "SCALE.Z": 1,
    "POSITION.X": 0,
    "POSITION.Y": 0,
    "POSITION.Z": 0,
    "OFFSET.X": 0,
    "OFFSET.Y": 0,
    "OFFSET.Z": 0,

    // Generated attributes.
    "deform.rotation.z": 0,
    "deform.offset.x": 0,
    "deform.offset.y": 0,
    "deform.length": 0,
    "deform.radius": 0,
    "rest.rotation.z": 0,
    "rest.offset.x": 0,
    "rest.offset.y": 0,
    "rest.length": 0,
    "rest.radius": 0,
  };

  /**
   * @type {Record<string, { x: number, y: number, z: number }>}
   */
  var attributeDefault3DValues = {
    "PIVOT": { x: 0, y: 0, z: 0 },
    "POSITION.3DPATH": { x: 0, y: 0, z: 0 },
    "OFFSET.3DPATH": { x: 0, y: 0, z: 0 },
    "SCALE.3DPATH": { x: 1, y: 1, z: 1 },

    // Generated attributes.
    "deform.offset.3DPATH": { x: 0, y: 0, z: 0 },
    "rest.offset.3DPATH": { x: 0, y: 0, z: 0 },
  };

  /**
   * @param {AttributeInfo} attribute
   */
  this.isDefault = function (attribute) {
    if ("constant" in attribute)
    {
      var defaultValue = attributeDefaultValues[attribute.path];
      if (defaultValue == null)
        return false;
      return attribute.constant == defaultValue;
    }
    if ("curve" in attribute)
      switch (attribute.curve.type)
      {
        case "PIVOT":
          var defaultValues = attributeDefault3DValues["PIVOT"];
          if (defaultValues == null)
            return false;
          return attribute.curve.points.every(function (pivot) {
            return pivot.x == defaultValues.x &&
              pivot.y == defaultValues.y &&
              pivot.z == defaultValues.z;
          });
        case "STREAM":
          var defaultValue = attributeDefaultValues[attribute.path];
          if (defaultValue == null)
            return false;
          return attribute.curve.valueAtIndex.every(function (value) {
            return value == defaultValue;
          });
        case "LINEAR":
          var defaultValue = attributeDefaultValues[attribute.path];
          if (defaultValue == null)
            return false;
          return attribute.curve.points.every(function (point) {
            return point.y == defaultValue;
          });
        case "BEZIER":
          var defaultValue = attributeDefaultValues[attribute.path];
          if (defaultValue == null)
            return false;
          return attribute.curve.points.every(function (point) {
            return point.y == defaultValue &&
              point.ly == defaultValue &&
              point.ry == defaultValue;
          });
        case "3DPATH":
          var defaultValues = attributeDefault3DValues[attribute.path];
          if (defaultValues == null)
            return false;
          return attribute.curve.points.every(function (point) {
            return point.x == defaultValues.x &&
              point.y == defaultValues.y &&
              point.z == defaultValues.z;
          });
      }
    return false;
  }
}
