/*
 * Copyright Toon Boom Animation Inc - 2021
 */

/**
 * Provides minimal ES6 array features back to array
 * @template {Array<any>} T
 * @param {T} array
 */
exports.Iter = function (array) {

  /**
   * Create new array converting each element to a new element of another type,
   * each new element is assumed to be an array that is appended to the output
   * @template U
   * @param {(element: T[number], index: number) => U[]} func
   */
  this.flatMap = function (func) {
    /**@type{U[]}*/
    var result = [];
    for (var i = 0; i < array.length; i++)
    {
      result = result.concat(func(array[i], i));
    }
    return result;
  }

  /**
   * Get the first element index in the array where the function is satisfied
   * @param {(element: T[number], index: number) => boolean} func
   */
  this.findIndex = function (func) {
    for (var i = 0; i < array.length; i++)
    {
      if (func(array[i], i))
      {
        return i;
      }
    }
    return null;
  }
}

/**
 * Returns true if an element is not null
 * @template T
 * @param {T | null | undefined} elem
 * @returns {elem is T}
 */
exports.Iter.notNull = function (elem) {
  return elem != null;
}

/**
 * @template T
 * @param {T[]} inputArr
 * @returns {T[][]} List of all possible orders of input array
 */
exports.Iter.allPermuations = function (inputArr) {
  /**@type T[][]*/
  var results = [];

  /**
   * @param {T[]} arr
   * @param {T[]} [inputMemo]
   * @returns {T[][]}
   */
  function permute(arr, inputMemo) {
    var cur, memo = inputMemo || [];

    for (var i = 0; i < arr.length; i++)
    {
      cur = arr.splice(i, 1);
      if (arr.length === 0)
      {
        results.push(memo.concat(cur));
      }
      permute(arr.slice(), memo.concat(cur));
      arr.splice(i, 0, cur[0]);
    }

    return results;
  }

  return permute(inputArr);
}

/**
 * @template T
 * @param {T[][]} inputArrs
 * @returns {T[][]} List of all possible selections of 1 element from each input array.
 * Eg. ab, cd -> ac, ad, bc, bd
 */
exports.Iter.allVariations = function (inputArrs) {
  if (inputArrs.length == 0) {
    return [];
  }
  if (inputArrs.length == 1) {
    return inputArrs[0].map(function (element) { return [element]; });
  }
  return new exports.Iter(inputArrs[0]).flatMap(function (inputArr) {
    return exports.Iter.allVariations(inputArrs.slice(1))
      .map(function (variation) { return [inputArr].concat(variation); })
  });
}
