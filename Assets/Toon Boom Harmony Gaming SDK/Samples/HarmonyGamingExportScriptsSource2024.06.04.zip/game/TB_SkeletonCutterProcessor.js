/*
 * Copyright Toon Boom Animation Inc - 2022
 */

var NodeUtil = require("./TB_NodeUtil.js");
var ObjUtil = require("./TB_ObjUtil.js");
var Iter = require("./TB_Iter.js").Iter;

/**
 * @param {{ exportVersion: number, bakeAllGroups: boolean }} settings
 */
exports.SkeletonCutterProcessor = function (settings) {

  /**
   * @param {Record<NodePath, UniqueNodePath>} nodePathToUnique
   * @param {NodePath} nodePath
   */
  function getInputNodes(nodePathToUnique, nodePath) {
    var isUniqueParent = function (/**@type NodePath*/nodePath) { return nodePathToUnique[nodePath] != null; }
    var relevantLinks = new NodeUtil.InputScan(nodePath, {
      shouldQuitBranch: isUniqueParent,
      isMatch: isUniqueParent,
    })
      .toArray()
      .map(function (nodePath) { return nodePathToUnique[nodePath]; });
    return relevantLinks;
  }

  /**
   * @param {UniqueNodePath[]} startingNodes
   * @param {Record<UniqueNodePath, UniqueNodePath[]>} nodeToLinked
   */
  function buildFullChains(startingNodes, nodeToLinked) {
    var chains = startingNodes.map(function (output) { return [output]; });
    var completeChains = [];
    var currentChain;
    while (currentChain = chains.pop())
    {
      var lastElement = currentChain[currentChain.length - 1];
      var linkedNodes;
      while ((linkedNodes = nodeToLinked[lastElement]) != null
        && linkedNodes.length > 0)
      {
        for (var i = 1; i < linkedNodes.length; i++)
        {
          chains.push(currentChain.concat(linkedNodes[i]));
        }
        lastElement = linkedNodes[0];
        currentChain.push(lastElement);
      }
      completeChains.push(currentChain);
    }

    return completeChains;
  }

  /**
   * @param {UniqueNodePath[][]} chains
   * @param {string} [uid]
   * @param {UniqueNodePath} [inputNodePath]
   */
  function makeLinkUnique(chains, uid, inputNodePath) {
    /**
     * @param {Link} link
     * @returns {Link}
     */
    return function (link) {
      var firstOnChain = chains.some(function (chain) { return chain[0] == link["out"].nodePath });
      var input = NodeUtil.decomposeUniqueNode(link["in"]);
      var output = NodeUtil.decomposeUniqueNode(link["out"].nodePath);
      return {
        "in": firstOnChain
          ? inputNodePath != null ? inputNodePath : link["in"]
          : NodeUtil.uniqueNodePath([input.uid, uid].join(), input.nodePath),
        "out": {
          nodePath: NodeUtil.uniqueNodePath([output.uid, uid].join(), output.nodePath),
          tag: link["out"].tag,
          inputPort: link["out"].inputPort,
        },
      }
    };
  }


  /**
   * Takes an existing array of links and links in generated cutter structures where
   * the original roots are referenced, removes existing cutter-matte branches.
   * @param {Array<Link>} links
   * @returns {Array<Link>}
   */
  this.processLinks = function (links) {

    if (settings.exportVersion == 2)
      return links;

    if (settings.exportVersion == 3)
      return links;

    /**
     * @param {UniqueNodePath[][]} chains
     * @returns {Link[]}
     */
    function linkSubsetFromChains(chains) {
      return links
        .filter(function (link) {
          return chains.some(function (chain) {
            return chain.indexOf(link["out"].nodePath) >= 0;
          });
        });
    }

    var cutterNodes = ObjUtil.entries(ObjUtil.fromEntries(links
      .filter(function (link) {
        var tag = NodeUtil.getUniqueNodeGameTag(settings, link.out.nodePath);
        return tag == "cutter" || tag == "inverseCutter";
      })
      .map(function (link) { return { key: link.out.nodePath, value: true } })))
      .map(function (entry) { return entry.key });

    cutterNodes
      .forEach(function (cutterNode) {
        var nodePath = NodeUtil.decomposeUniqueNode(cutterNode).nodePath;
        var nodeToInputs = /**@type Record<UniqueNodePath, UniqueNodePath[]>*/({});
        var nodeToOutputs = /**@type Record<UniqueNodePath, UniqueNodePath[]>*/({});
        links.forEach(function (link) {
          var inputs = nodeToInputs[link.out.nodePath];
          nodeToInputs[link.out.nodePath] =
            inputs == null
              ? [link["in"]]
              : inputs.concat(link["in"])
          var outputs = nodeToOutputs[link["in"]];
          nodeToOutputs[link["in"]] =
            outputs == null
              ? [link.out.nodePath]
              : outputs.concat(link.out.nodePath);
        });
        var cutterInLinks = nodeToInputs[cutterNode];
        if (cutterInLinks == null)
        {
          return null;
        }
        var nodePathToUnique = ObjUtil.fromEntries(cutterInLinks
          .map(function (nodePath) { return { key: NodeUtil.decomposeUniqueNode(nodePath).nodePath, value: nodePath }; }));
        var cutteeInputNodes = getInputNodes(nodePathToUnique, node.srcNode(nodePath, 0));
        var matteInputNodes = getInputNodes(nodePathToUnique, node.srcNode(nodePath, 1));
        var fullChains = buildFullChains(matteInputNodes.concat(cutteeInputNodes), nodeToInputs);
        var minLength = fullChains
          .map(function (chain) { return chain.length; })
          .reduce(function (minLength, length) { return Math.min(length, minLength); });
        var candidateAncestor = /**@type UniqueNodePath | null*/(null);
        for (var elementIdx = 0; elementIdx < minLength && candidateAncestor == null; elementIdx++)
        {
          for (var chainIdx = 0; chainIdx < fullChains.length && candidateAncestor == null; chainIdx++)
          {
            var ancestorIdx = new Iter(fullChains[chainIdx]).findIndex(function (nodePath) {
              return fullChains.every(function (otherChain, otherIdx) {
                return chainIdx == otherIdx || otherChain.indexOf(nodePath) >= 0;
              });
            });
            if (ancestorIdx != null)
            {
              candidateAncestor = fullChains[chainIdx][ancestorIdx];
            }
          }
        }
        if (candidateAncestor == null)
        {
          return null;
        }
        var commonAncestor = candidateAncestor;
        var outputsFromAncestor = buildFullChains(nodeToOutputs[commonAncestor], nodeToOutputs)
          .map(function (chain) {
            var cutterIdx = chain.indexOf(cutterNode);
            return cutterIdx < 0
              ? chain[chain.length - 1]
              : chain[cutterIdx - 1];
          });
        var nodeOrder = ObjUtil.fromEntries(links.map(function (link, index) { return { key: link.out.nodePath, value: index }; }));
        var chainsFromAncestor = buildFullChains(
          outputsFromAncestor.sort(function (a, b) { return nodeOrder[a] - nodeOrder[b]; }),
          nodeToInputs)
          .map(function (chain) {
            var ancestorIdx = chain.indexOf(commonAncestor);
            return chain.splice(0, ancestorIdx).reverse();
          });

        var matteChains = chainsFromAncestor.filter(function (chain) { return matteInputNodes.indexOf(chain[chain.length - 1]) >= 0; })
        var cutteeChains = chainsFromAncestor.filter(function (chain) { return cutteeInputNodes.indexOf(chain[chain.length - 1]) >= 0; });
        var indexOfCutteeChainCandidate = new Iter(chainsFromAncestor).findIndex(function (chain) {
          return matteChains.indexOf(chain) >= 0 || cutteeChains.indexOf(chain) >= 0;
        }) || 0;
        var indexOfCutteeChain = indexOfCutteeChainCandidate;
        var incidentalChainsBefore = chainsFromAncestor.filter(function (chain, index) {
          return index < indexOfCutteeChain && matteChains.indexOf(chain) < 0 && cutteeChains.indexOf(chain) < 0
        });
        var incidentalChainsAfter = chainsFromAncestor.filter(function (chain, index) {
          return index > indexOfCutteeChain && matteChains.indexOf(chain) < 0 && cutteeChains.indexOf(chain) < 0
        });

        var cutterNodeInfo = NodeUtil.decomposeUniqueNode(cutterNode);
        var rootCutterNode = NodeUtil.uniqueNodePath([cutterNodeInfo.uid, "cutter"].join(), cutterNodeInfo.nodePath);
        var rootMatteNode = NodeUtil.uniqueNodePath([cutterNodeInfo.uid, "matte"].join(), cutterNodeInfo.nodePath);

        /**@type Link*/
        var rootCutterLink = {
          "in": candidateAncestor,
          "out": {
            nodePath: rootCutterNode,
            tag: NodeUtil.getUniqueNodeGameTag(settings, cutterNode),
            inputPort: 0,
          },
        };
        /**@type Link*/
        var rootMatteLink = {
          "in": rootCutterNode,
          "out": {
            nodePath: rootMatteNode,
            tag: "matte",
            inputPort: 0,
          },
        };

        var incidentalLinksBefore = linkSubsetFromChains(incidentalChainsBefore);
        var cutteeLinks = linkSubsetFromChains(cutteeChains)
          .map(makeLinkUnique(cutteeChains, "cuttee", rootCutterNode));
        var matteLinks = linkSubsetFromChains(matteChains)
          .map(makeLinkUnique(matteChains, "matte", rootMatteNode));
        var incidentalLinksAfter = linkSubsetFromChains(incidentalChainsAfter);

        var isExistingToRemove = ObjUtil.fromEntries(new Iter(chainsFromAncestor)
          .flatMap(function (chain) {
            return chain
              .map(function (nodePath) {
                return { key: nodePath, value: true };
              })
              .filter(Iter.notNull);
          })
          .concat({ key: cutterNode, value: true }));

        links = new Iter(links).flatMap(function (link) {
          if (link["out"].nodePath == candidateAncestor)
          {
            return [link]
              .concat(incidentalLinksAfter)
              .concat(matteLinks.length == 0 && cutteeLinks.length == 0
                ? []
                : [rootCutterLink, rootMatteLink]
                  .concat(matteLinks)
                  .concat(cutteeLinks))
              .concat(incidentalLinksBefore)
          }
          if (isExistingToRemove[link["out"].nodePath])
          {
            return [];
          }
          return [link];
        });
      });
    return links;
  }
}