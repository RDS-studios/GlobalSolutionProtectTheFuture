#include "XML_ProjectLoader.h"
#include "XML_StageSaxParser.h"
#include "XML_SkeletonSaxParser.h"
#include "XML_AnimationSaxParser.h"
#include "XML_DrawingAnimationSaxParser.h"
#include "XML_SpriteSheetSaxParser.h"

#include "Base/STD_Types.h"
#include "Support/filesystem.hpp"

namespace
{
  void parseXmlFile( const STD_String &filename, XML_SaxParserComponentPtr_t mainComponent )
  {
    XML_SaxParserDelegator delegator(mainComponent);
    XML_SaxParser sax;

    sax.setDelegator( &delegator );
    sax.parse( filename.c_str() );
  }
}

void XML_ProjectLoader::loadStageClipNames( const STD_String &projectFolder, ClipDataCol_t&clipNames )
{
  XML_SaxParserComponentPtr_t mainComponent = new XML_StageNamesSaxParser(projectFolder, clipNames);
  parseXmlFile( projectFolder + "/stage.xml", mainComponent );
}

void XML_ProjectLoader::loadSkinNames(const STD_String& projectFolder, HarmonyNodeCol_t& nodes, HarmonyIdCol_t& skinNames, HarmonyIdCol_t& groupNames)
{
    XML_SaxParserComponentPtr_t mainComponent = new XML_SkinsNamesSaxParser(projectFolder, nodes, skinNames, groupNames);
    parseXmlFile(projectFolder + "/stage.xml", mainComponent);
}

void XML_ProjectLoader::loadMetas(const STD_String& projectFolder, StringPairsCol_t& props, StringPairsCol_t& anchors, GenericMetaCol_t& metas)
{
    XML_SaxParserComponentPtr_t mainComponent = new XML_MetaSaxParserComponent(projectFolder, props, anchors, metas);
    parseXmlFile(projectFolder + "/stage.xml", mainComponent);
}

void XML_ProjectLoader::loadStageClip( const STD_String &projectFolder, const STD_String &clipName, RD_ClipDataCore *clip )
{
  XML_SaxParserComponentPtr_t mainComponent = new XML_StageSaxParser(projectFolder, clipName, clip);
  parseXmlFile( projectFolder + "/stage.xml", mainComponent );
}

void XML_ProjectLoader::loadSkeleton( const STD_String &projectFolder, const STD_String &skeletonName, TR_NodeTree *nodeTree )
{
  XML_SaxParserComponentPtr_t mainComponent = new XML_SkeletonSaxParser(skeletonName, nodeTree);
  parseXmlFile( projectFolder + "/skeleton.xml", mainComponent );
}

void XML_ProjectLoader::loadAnimation( const STD_String &projectFolder, const STD_String &animationName, TR_NodeTree *nodeTree )
{
  XML_SaxParserComponentPtr_t mainComponent = new XML_AnimationSaxParser(animationName, nodeTree);
  parseXmlFile( projectFolder + "/animation.xml", mainComponent );
}

void XML_ProjectLoader::loadDrawingAnimation( const STD_String &projectFolder, const STD_String &drawingAnimationName, TR_NodeTree *nodeTree )
{
  XML_SaxParserComponentPtr_t mainComponent = new XML_DrawingAnimationSaxParser(drawingAnimationName, nodeTree);
  parseXmlFile( projectFolder + "/drawingAnimation.xml", mainComponent );
}

void XML_ProjectLoader::loadSpriteSheetNames( const STD_String &projectFolder, StringPairCol_t &sheetNames )
{
  XML_SaxParserComponentPtr_t mainComponent = new XML_SpriteSheetNamesSaxParser(sheetNames);
  parseXmlFile( projectFolder + "/spriteSheets.xml", mainComponent );
}

void XML_ProjectLoader::loadSpriteSheetResolutionNames( const STD_String &projectFolder, const STD_String &sheetName, StringPairCol_t &sheetNames )
{
  XML_SaxParserComponentPtr_t mainComponent = new XML_SpriteSheetNamesSaxParser(sheetName, sheetNames);
  parseXmlFile( projectFolder + "/spriteSheets.xml", mainComponent );
}

void XML_ProjectLoader::loadSpriteSheet( const STD_String &projectFolder, const STD_String &sheetName, const STD_String &sheetResolution, RD_SpriteSheetCore *sheet )
{
  XML_SaxParserComponentPtr_t mainComponent = new XML_SpriteSheetSaxParser(projectFolder, sheetName, sheetResolution, sheet);
  parseXmlFile( projectFolder + "/spriteSheets.xml", mainComponent );
}

bool XML_ProjectLoader::hasSpriteSheet(const STD_String& projectFolder)
{
    return ghc::filesystem::exists(projectFolder + "/spriteSheets.xml");
}

void XML_ProjectLoader::loadSprites(const STD_String& projectFolder, STD_Vector<XML_SpritesSaxParser::CropInfo> &cropInfoCol)
{
    ghc::filesystem::path path = projectFolder + "/sprites";
    if (!ghc::filesystem::exists(path))
    {
        return;
    }

    size_t pathLength = path.generic_string().length();
    for (const ghc::filesystem::directory_entry& sheetEntry : ghc::filesystem::directory_iterator(path))
    {
        if (sheetEntry.is_directory())
        {
            for (const ghc::filesystem::directory_entry& resolutionEntry : ghc::filesystem::directory_iterator(sheetEntry.path()))
            {
                if (resolutionEntry.is_directory())
                {
                    for (const ghc::filesystem::directory_entry& spriteEntry : ghc::filesystem::directory_iterator(resolutionEntry.path()))
                    {
                        const STD_String filePath = spriteEntry.path().generic_string();
                        if (filePath.substr(filePath.find_last_of(".") + 1) == "sprite")
                        {
                            XML_SpritesSaxParser::CropInfo cropInfo = XML_SpritesSaxParser::CropInfo();
                            cropInfo.name = filePath.substr(pathLength + 1, filePath.find_last_of(".") - pathLength - 1);
                            XML_SaxParserComponentPtr_t mainComponent = new XML_SpritesSaxParser(&cropInfo);
                            parseXmlFile(filePath, mainComponent);
                            cropInfoCol.push_back(cropInfo);
                        }
                    }
                }
            }
        }
    }
}

void XML_ProjectLoader::loadSprite(const STD_String& spritePath, XML_SpritesSaxParser::CropInfo* cropInfo)
{
    XML_SaxParserComponentPtr_t mainComponent = new XML_SpritesSaxParser(cropInfo);
    parseXmlFile(spritePath, mainComponent);
}

void XML_ProjectLoader::loadSpriteSheet( const STD_String &projectFolder, const STD_String &sheetName, RD_SpriteSheetCore *sheet )
{
  //  Retrieve a default resolution name
  StringPairCol_t sheetNames;
  loadSpriteSheetResolutionNames(projectFolder, sheetName, sheetNames );

  if ( !sheetNames.empty() )
  {
    loadSpriteSheet(projectFolder, sheetName, sheetNames.front().second, sheet);
  }
}
