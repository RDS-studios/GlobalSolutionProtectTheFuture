#include "IO_File.h"

#include <stdio.h>

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - IO_File::Impl
#endif
class IO_File::Impl
{
  MEM_OVERRIDE

  friend class IO_File;

public:

  Impl() :
    _file(0)
  {
  }

  ~Impl()
  {
  }

private:

  FILE        *_file;
  ghc::filesystem::path  _path;

};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - IO_File::Impl
#endif

IO_File::IO_File()
{
  _i = new Impl;
}

IO_File::~IO_File()
{
  if (_i->_file)
    close();

  delete _i;
}


void IO_File::close( )
{
  fclose( _i->_file );
	_i->_file = 0;
}

bool IO_File::open( const ghc::filesystem::path& filename, bool bInput )
{
	const char *pOpenArg = bInput ? "rb" : "w+b";
	_i->_file = std::fopen( filename.string().c_str(), pOpenArg);
	if( _i->_file == 0 )
		return false;

	return true;
}


bool IO_File::openForInput( const ghc::filesystem::path&filename )
{
	if ( open( filename, true ) )
	{
		_i->_path = filename;
		return true;
	}
	else
		return false;
}


bool IO_File::createForOutput( const ghc::filesystem::path&filename )
{
	//PL_FileUtil::BackupFile(filename);
	if ( open( filename, false ) )
	{
		_i->_path = filename;
		return true;
	}
	else
		return false;
}


size_t IO_File::read(void* lpBuf, size_t nCount)
{
	size_t nRes = fread( lpBuf, 1, nCount, _i->_file );
  return nRes;

	// Expects either 0 (if reading the end of file )
	if( ( nRes != nCount ))
	{
    /*
		QString ws;
		if( feof( m_pFile ))
		{
			ws = qApp->translate("PersistentObj", "Reading past end of file");
		}
		else
		{
			ws = qApp->translate("PersistentObj", "Error reading from file"); 
		}
		throw DB_Exception( ws );
    */
	}
}

void IO_File::write(const void* lpBuf, size_t nCount)
{
	size_t nRes = fwrite( lpBuf, 1, nCount, _i->_file );
	if( nRes != nCount )
	{
    /*
		throw DB_Exception(qApp->translate("PersistentObj", "Unable to write to file" ));
    */
	}
}

void IO_File::seek(size_t addr)
{
	fseek(_i->_file, addr, 0);
}

size_t IO_File::tell()
{
	return ftell(_i->_file);
}

void IO_File::reset()
{
	if( _i->_file )
	{
		rewind( _i->_file );
	}
}

bool IO_File::isEOF()
{
	return feof(_i->_file);
}

size_t IO_File::size() const
{
	return ghc::filesystem::file_size(_i->_path);
}

UT_String IO_File::streamName() const
{
	return _i->_path.filename().string().c_str();
}

ghc::filesystem::path IO_File::streamSpec() const
{
	return _i->_path;
}

