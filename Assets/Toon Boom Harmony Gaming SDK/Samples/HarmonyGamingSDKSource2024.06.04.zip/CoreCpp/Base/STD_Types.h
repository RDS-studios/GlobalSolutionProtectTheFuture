#ifndef _STD_TYPES_H_
#define _STD_TYPES_H_

#include <string>
#include <sstream>

#define STD_String std::string
#define STD_Stringstream std::stringstream
#define STD_stoi std::stoi

#endif /* _STD_TYPES_H_ */
