
#ifndef _HARMONY_RENDERER_H_
#define _HARMONY_RENDERER_H_

// Which platform we are on?
#if _MSC_VER && !NN_NINTENDO_SDK
#define UNITY_WIN 1
#else
#define UNITY_NOT_WIN 1
#endif

// Attribute to make function be exported from a plugin
#if UNITY_WIN || TARGET_PS4
#define EXPORT_API __declspec(dllexport)
#else
#define EXPORT_API
#endif

#endif /* _HARMONY_RENDERER_H_ */
