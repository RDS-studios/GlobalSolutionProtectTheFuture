
#include "RD_RenderScriptFx.h"

#include "Base/PL_Mutex.h"
#include "Base/STD_Types.h"
#include "Base/STD_Containers.h"

#include <float.h>

#define MAX_ACTIVE_EFFECTS 1

#define HIGH_QUALITY_DISCRETIZATION   10.0
#define MEDIUM_QUALITY_DISCRETIZATION 20.0
#define LOW_QUALITY_DISCRETIZATION    50.0

#define PRE_MATRIX_INDEX    0
#define MATRIX_INDEX        1
#define POST_MATRIX_INDEX   2

#define FX_U_INDEX          0
#define FX_V_INDEX          1
#define FX_ADD_INDEX        2
#define FX_MULT_INDEX       3
#define FX_VP_U1_INDEX      4
#define FX_VP_V1_INDEX      5
#define FX_VP_U2_INDEX      6
#define FX_VP_V2_INDEX      7

#define COORD_X0            0
#define COORD_Y0            1
#define COORD_X1            2
#define COORD_Y1            3
#define COORD_X2            4
#define COORD_Y2            5
#define COORD_X3            6
#define COORD_Y3            7

#define INIT_BOUND( val, min_bound, max_bound ) \
  min_bound = val; \
  max_bound = val;

#define SET_BOUND( val, min_bound, max_bound ) \
  if ( val < min_bound ) \
    min_bound = val; \
  else if ( val > max_bound ) \
    max_bound = val;

#define VEC_DET( v1x, v1y, v2x, v2y ) \
  v1x * v2y - v1y * v2x

#define ROUND_VALUE( val ) \
  floorf( (val * 64.0f) + 0.5f ) / 64.0f;

#define WORLD_TO_CLIP( val ) \
  (int)(val * 1024.0f)

#define CLIP_TO_WORLD( val ) \
  (val / 1024.0f)

namespace
{
	typedef void* CacheKey_t;

	/*!
	 *  @struct BoneMapping
	 *  Single vertex mapping to bone hierarchy.
	 */
	struct BoneMapping
	{
		float    _boneIndex1;
		float    _boneWeight1;

		float    _boneIndex2;
		float    _boneWeight2;
	};

	static BoneMapping g_defaultMapping = { 0.0f, 1.0f, 0.0f, 0.0f };

	/*!
	 *  @struct SpriteMapping
	 *  Sprite discretization and mapped data.
	 */
	struct SpriteMapping
	{
		SpriteMapping(unsigned xSteps, unsigned ySteps) :
			_xSteps(xSteps),
			_ySteps(ySteps)
		{
			_bones = new BoneMapping[(xSteps + 1) * (ySteps + 1)];
		}

		~SpriteMapping()
		{
			delete[] _bones;
		}

		BoneMapping *boneMapping(unsigned x, unsigned y)
		{
			return &_bones[(_xSteps + 1) * y + x];
		}

		unsigned       _xSteps;
		unsigned       _ySteps;

		BoneMapping   *_bones;
	};

    typedef STD_Map< CacheKey_t, SpriteMapping* > SpriteMappingCol_t;

    typedef STD_Map< int, STD_String > SkinMappingCol_t;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - RD_RenderScriptFx::Impl
#endif

class RD_RenderScriptFx::Impl
{
	friend class RD_RenderScriptFx;

public:

	Impl() :
		_verticesCount(0),
		_indicesCount(0),
		_texturesCount(0),
		_discretizationStep(MEDIUM_QUALITY_DISCRETIZATION),
		_frame(0.0f),
		_renderDirty(true)
	{
	}

	~Impl()
	{
	}

	void ResetVectors()
	{
		_verticesCount = 0;
		_indicesCount = 0;

		for (int i = 0; i < _texturesCount; i++)
		{
			(&_textures[i])->_textureId = -1;
			(&_textures[i])->_count = 0;
		}
		_texturesCount = 0;
	}

	void AddOrMergeTextureId(int textureId, int maskTextureId, int indexCount)
	{
		TextureMapping* tmap = nullptr;
		if (_texturesCount != 0)
		{
			tmap = &_textures[_texturesCount - 1];
		}

		if (tmap != nullptr && tmap->_textureId == textureId && tmap->_maskTextureId == maskTextureId)
		{
			tmap->_count += indexCount;
		}
		else
		{
			if (_textures.size() > _texturesCount)
			{
				_textures[_texturesCount] = TextureMapping(textureId, maskTextureId, indexCount);
			}
			else
			{
				_textures.push_back(TextureMapping(textureId, maskTextureId, indexCount));
			}
			_texturesCount++;
		}
	}

private:

	VertexDataCol_t         _vertices;
	size_t                  _verticesCount;

	IndexDataCol_t          _indices;
	size_t                  _indicesCount;

	TextureDataCol_t        _textures;
	size_t                  _texturesCount;

	RD_ClipDataPtr_t        _clipData;

	STD_String              _sheetResolution;

    SkinMappingCol_t        _skins;

	int                     _discretizationStep;

	SpriteMappingCol_t      _cachedMapping;

	RenderBatchCol_t        _batches;

	float                   _frame;

	bool                    _renderDirty;

	PL_Mutex                _mutex;
};

namespace
{
	void calculateBoneWeight(RD_Composition::BoneEffect *boneEffect, float xCoord, float yCoord, float &distanceSq, float &weight, unsigned &index)
	{
		//  v1: start to coord.
		float v1x = xCoord - (float)boneEffect->_restStart.x();
		float v1y = yCoord - (float)boneEffect->_restStart.y();

		//  v2: start to end.
		float v2x = float(boneEffect->_restEnd.x() - boneEffect->_restStart.x());
		float v2y = float(boneEffect->_restEnd.y() - boneEffect->_restStart.y());

		//  v1 dot v2
		float dot = v1x * v2x + v1y * v2y;

		float lengthSq = v2x*v2x + v2y*v2y;

		//  coordinate is behind bone.
		if (dot <= 0)
		{
			distanceSq = v1x*v1x + v1y*v1y;

			//  Weight is projected length square to start.
			weight = dot * dot / lengthSq;
			index = PRE_MATRIX_INDEX;
			return;
		}

		//  coordinate is in front of bone.
		if (dot >= lengthSq)
		{
			float v3x = xCoord - (float)boneEffect->_restEnd.x();
			float v3y = yCoord - (float)boneEffect->_restEnd.y();

			distanceSq = v3x*v3x + v3y*v3y;

			//  Weight is projected length square to end.
			float dot2 = v3x * v2x + v3y * v2y;
			weight = dot2 * dot2 / lengthSq;

			index = POST_MATRIX_INDEX;
			return;
		}

		float cross = v1x * v2y - v1y * v2x;

		distanceSq = weight = cross * cross / lengthSq;
		index = MATRIX_INDEX;
	}

	SpriteMapping *createSpriteMapping(const RD_Composition::CompositionNode *node, const RD_SpriteSheet::SpriteData *spriteData, int discretizationStep)
	{
		bool isDeformed = !node->_bones.empty();

		unsigned xSteps = 1u;
		unsigned ySteps = 1u;

		//  Deformed sprite, discretize geometry for smoother deformation.
		if (isDeformed)
		{
			const int WIDTH = spriteData->_rect._w;
			const int HEIGHT = spriteData->_rect._h;
			const double ASPECT_RATIO = (double)WIDTH / (double)HEIGHT;

			double discretizationX, discretizationY;
			if (WIDTH > HEIGHT)
			{
				discretizationX = (double)discretizationStep * ASPECT_RATIO;
				discretizationY = (double)discretizationStep;
			}
			else
			{
				discretizationX = (double)discretizationStep;
				discretizationY = (double)discretizationStep * 1.0 / ASPECT_RATIO;
			}

			xSteps = std::max(1u, unsigned(discretizationX));
			ySteps = std::max(1u, unsigned(discretizationY));
		}

		return new SpriteMapping(xSteps, ySteps);
	}

	void updateBoneMapping(const RD_Composition::CompositionNode *node, float xCoord, float yCoord, BoneMapping *boneMapping)
	{
		bool isDeformed = !node->_bones.empty();

		if (isDeformed)
		{
			float bestDistanceSq = FLT_MAX;

			//  Note.  Using a quad tree could speed up calculations.
			for (RD_Composition::BoneEffectCol_t::const_iterator i = node->_bones.begin(), iEnd = node->_bones.end(); i != iEnd; ++i)
			{
				RD_Composition::BoneEffect *boneEffect = *i;
				float distanceSq;
				float weight;
				unsigned index;

				calculateBoneWeight(boneEffect, xCoord, yCoord, distanceSq, weight, index);

				//  Better match.
				if (distanceSq < bestDistanceSq)
				{
					boneMapping->_boneIndex1 = float(boneEffect->_effectIdx * 3 + index + 1);
					bestDistanceSq = distanceSq;

					if (index == PRE_MATRIX_INDEX)
					{
						if (boneEffect->_parentBone == NULL)
						{
							//  First bone, only use this bone in skinning.
							boneMapping->_boneWeight1 = 1.0;
							boneMapping->_boneIndex2 = boneMapping->_boneWeight2 = 0.0f;
						}
						else
						{
							//  Skinning is a combination of this bone and its parent.
							float distanceSq2;
							float weight2;
							unsigned index2;
							calculateBoneWeight(boneEffect->_parentBone, xCoord, yCoord, distanceSq2, weight2, index2);

							boneMapping->_boneWeight1 = weight2 / (weight + weight2);

							boneMapping->_boneIndex2 = float(boneEffect->_parentBone->_effectIdx * 3 + index2 + 1);
							boneMapping->_boneWeight2 = weight / (weight + weight2);

						}
					}
					else if (index == POST_MATRIX_INDEX)
					{
						if (boneEffect->_childBones.empty())
						{
							// Last bone, only use this bone in skinning.
							boneMapping->_boneWeight1 = 1.0;
							boneMapping->_boneIndex2 = boneMapping->_boneWeight2 = 0.0;
						}
						else
						{
							//  Skinning is a combination of this bone and its nearest child.
							float bestDistanceSq2 = FLT_MAX;
							float bestWeight2;
							unsigned bestIndex2 = 0u;
							RD_Composition::BoneEffect *bestChildBone = NULL;

							//  Note! There might be a more effective way of finding the nearest bone.
							for (RD_Composition::BoneEffectCol_t::const_iterator i = boneEffect->_childBones.begin(), iEnd = boneEffect->_childBones.end(); i != iEnd; ++i)
							{
								RD_Composition::BoneEffect *childBone = *i;

								float distanceSq2;
								float weight2;
								unsigned index2;
								calculateBoneWeight(*i, xCoord, yCoord, distanceSq2, weight2, index2);

								if (distanceSq2 < bestDistanceSq2)
								{
									bestDistanceSq2 = distanceSq2;
									bestWeight2 = weight2;
									bestIndex2 = index2;
									bestChildBone = childBone;
								}
							}

							if (bestChildBone != NULL)
							{
								boneMapping->_boneWeight1 = bestWeight2 / (weight + bestWeight2);

								boneMapping->_boneIndex2 = float(bestChildBone->_effectIdx * 3 + bestIndex2 + 1);
								boneMapping->_boneWeight2 = weight / (weight + bestWeight2);
							}
							else
							{
								//  Shouldn't happen.
								boneMapping->_boneWeight1 = 1.0;
								boneMapping->_boneIndex2 = boneMapping->_boneWeight2 = 0.0f;
							}
						}
					}
					else
					{
						//  Only skin with this bone.
						boneMapping->_boneWeight1 = 1.0;
						boneMapping->_boneIndex2 = boneMapping->_boneWeight2 = 0.0;
					}
				}
			}
		}
		else
		{
			//  Default skinning.
			//  1st bone uses 1st bone index (identity matrix) with a weight value of 1.
			boneMapping->_boneIndex1 = 0.0f;
			boneMapping->_boneWeight1 = 1.0f;
			//  2nd bone uses (whatever) bone index with a weight value of 0.
			boneMapping->_boneIndex2 = 0.0f;
			boneMapping->_boneWeight2 = 0.0f;
		}
	}

	void applyLinearBaseSkinning(float weight1,
		const float *matrix1,
		float weight2,
		const float *matrix2,
		float x,
		float y,
		float &newx,
		float &newy)
	{
		//  Skin current vertex using two bone matrices and their weights.
		//  This will be used as software fallback for gpu skinning.
		newx = (matrix1[0] * weight1 + matrix2[0] * weight2) * x + (matrix1[4] * weight1 + matrix2[4] * weight2) * y +
			(matrix1[12] * weight1 + matrix2[12] * weight2);
		newy = (matrix1[1] * weight1 + matrix2[1] * weight2) * x + (matrix1[5] * weight1 + matrix2[5] * weight2) * y +
			(matrix1[13] * weight1 + matrix2[13] * weight2);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - RD_RenderScriptFx
#endif

RD_RenderScriptFx::RD_RenderScriptFx()
{
	_i = new Impl;
}

RD_RenderScriptFx::RD_RenderScriptFx(const RD_RenderScriptMetaPtr_t &meta) :
	RD_RenderScript(meta)
{
	_i = new Impl;
}

RD_RenderScriptFx::~RD_RenderScriptFx()
{
	cleanup();
	delete _i;
}

void RD_RenderScriptFx::update(const RD_ClipDataPtr_t &pClipData, int projectId, const STD_String &sheetResolution, float frame, int discretizationStep)
{
	lock();

	//  Reset vertices and indices count.  Both array remain allocated to limit reallocations.
	_i->ResetVectors();

	//  Render now set to frame.
	_i->_frame = frame;

	//  Clip data has changed between two renders.  Replace hierarchy with new clip data.
	if (pClipData != _i->_clipData)
	{
		//  Reset composition and replace with new hiearchy.
		_i->_clipData = pClipData;
		cleanup();
	}

	//  sheet resolution has changed, a new sprite sheet must be loaded.  Rebuild hierarchy.
	if (sheetResolution.compare(_i->_sheetResolution) != 0)
	{
		//  Reset composition and replace with new hiearchy.
		_i->_sheetResolution = sheetResolution;
		cleanup();
	}

	if (_i->_discretizationStep != discretizationStep)
	{
		_i->_discretizationStep = discretizationStep;
		clearSpriteMapping();
	}

	//  If there is no composition data, build from clip data.
	if (_compositions.empty())
	{
		//  Clear batches.
		//  It could be reused to limit memory allocations.
		_i->_batches.clear();
		buildComposition(pClipData, frame, projectId, sheetResolution);
	}

    //  Update existing compositions.
    updateComposition(frame);

	updateRequests();

	//  Resize batch container if smaller than request size.
	if (_requests.size() > _i->_batches.size())
		_i->_batches.resize(_requests.size(), RenderBatch());

	//  Create batches from requests.  This will generate vertices and indices.
	RenderBatchCol_t::iterator iBatch = _i->_batches.begin();
	for (RenderBatchRequestCol_t::const_iterator i = _requests.begin(), iEnd = _requests.end(); i != iEnd; ++i, ++iBatch)
	{
		updateBatch(i->_composition, i->_range.first, i->_range.second, *iBatch);
	}

	_i->_renderDirty = true;

	unlock();
}

void RD_RenderScriptFx::updateWithBlending( const RD_ClipDataPtr_t &pClipDataFrom, int projectId, const STD_String &sheetResolution, float frameFrom, float frameTo, unsigned int color, int discretizationStep , float fullBlendTime, float currentBlendTime,int blendID ){
	lock();

	//  Reset vertices and indices count.  Both array remain allocated to limit reallocations.
	_i->ResetVectors();

	//  Render now set to frame.
	_i->_frame = frameFrom;

	//  Clip data has changed between two renders.  Replace hierarchy with new clip data.
	if ( pClipDataFrom != _i->_clipData)
	{
		//  Reset composition and replace with new hiearchy.
		_i->_clipData = pClipDataFrom;
		cleanup();
	}

	//  sheet resolution has changed, a new sprite sheet must be loaded.  Rebuild hierarchy.
	if ( sheetResolution.compare( _i->_sheetResolution ) != 0 )
	{
		//  Reset composition and replace with new hiearchy.
		_i->_sheetResolution = sheetResolution;
		cleanup();
	}

	if ( _i->_discretizationStep != discretizationStep )
	{
		_i->_discretizationStep = discretizationStep;
		clearSpriteMapping();
	}

	//  If there is no composition data, build from clip data.
	if ( _compositions.empty() )
	{
		//  Clear batches.
		//  It could be reused to limit memory allocations.
		_i->_batches.clear();
		buildCompositionWithBlending( pClipDataFrom, frameFrom,frameTo, projectId, sheetResolution,fullBlendTime, currentBlendTime,blendID );
	}
	else
	{
		//  Update existing compositions.
		updateCompositionWithBlending( frameFrom,frameTo, fullBlendTime, currentBlendTime,blendID );
	}

	updateRequests();

	//  Resize batch container if smaller than request size.
	if (_requests.size() > _i->_batches.size())
		_i->_batches.resize( _requests.size(), RenderBatch() );

	//  Create batches from requests.  This will generate vertices and indices.
	RenderBatchCol_t::iterator iBatch = _i->_batches.begin();
	for ( RenderBatchRequestCol_t::const_iterator i = _requests.begin(), iEnd = _requests.end() ; i!=iEnd ; ++i, ++iBatch )
	{
		updateBatch( i->_composition, i->_range.first, i->_range.second, *iBatch );
	}

	_i->_renderDirty = true;

	unlock();
}

bool RD_RenderScriptFx::supportsFeature(Feature feature) const
{
	static Feature allFeatures = RD_RenderScriptFx::supportedFeatures();
	return (allFeatures & feature) == feature;
}

RD_RenderScript::Feature RD_RenderScriptFx::supportedFeatures()
{
	static Feature allFeatures = Feature(ePlainFeature | eCutterFeature | eDeformationFeature);
	return allFeatures;
}

bool RD_RenderScriptFx::isDirty(float frame) const
{
	return (frame != _i->_frame);
}

bool RD_RenderScriptFx::isRenderDirty() const
{
	return _i->_renderDirty;
}


const RD_RenderScriptFx::VertexData *RD_RenderScriptFx::vertices() const
{
	return _i->_vertices.data();
}

size_t RD_RenderScriptFx::verticesCount() const
{
	return _i->_verticesCount;
}

const RD_RenderScriptFx::Index_t *RD_RenderScriptFx::indices() const
{
	return _i->_indices.data();
}

size_t RD_RenderScriptFx::indicesCount() const
{
	return _i->_indicesCount;
}

const RD_RenderScriptFx::TextureMapping *RD_RenderScriptFx::textures() const
{
	return _i->_textures.data();
}

size_t RD_RenderScriptFx::texturesCount() const
{
	return _i->_texturesCount;
}

const float *RD_RenderScriptFx::bones() const
{
	return &_i->_batches[0]._uniformBoneMatrices[0]._data[0];
}

size_t RD_RenderScriptFx::bonesCount() const
{
	if (_i->_batches.size() == 0)
	{
		return 0;
	}
	return _i->_batches[0]._uniformBoneMatrices.size();
}

void RD_RenderScriptFx::cleanup()
{
	RD_RenderScript::cleanup();
	clearSpriteMapping();
}

void RD_RenderScriptFx::clearSpriteMapping()
{
	//  Cleanup cached mapping
	for (SpriteMappingCol_t::const_iterator i = _i->_cachedMapping.begin(), iEnd = _i->_cachedMapping.end(); i != iEnd; ++i)
	{
		delete i->second;
	}
	_i->_cachedMapping.clear();
}

void RD_RenderScriptFx::updateBatch(const RD_Composition *composition,
	const RD_Composition::CompositionNodeCol_t::const_iterator iCompositionStart,
	const RD_Composition::CompositionNodeCol_t::const_iterator iCompositionEnd,
	RenderBatch &renderBatch)
{
	const RD_SpriteSheetPtr_t spriteSheet = composition->spriteSheet();
	//ASSERT(spriteSheet.isValid());

	//const IM_ImagePtr_t &spriteSheetImage = spriteSheet->image();
	//ASSERT(spriteSheetImage.isValid());

	//_i->_batches.push_back( RenderBatch() );
	//RenderBatch &renderBatch = _i->_batches.back();

	renderBatch._indexOffset = (unsigned)_i->_indicesCount;
	renderBatch._vertexOffset = (unsigned)_i->_verticesCount;

	renderBatch._spriteSheet = spriteSheet;

	unsigned index = renderBatch._vertexOffset;

	float  coords[8];
	float  coords2[4];

	//  Vertex parameters for cutter
	//  | fxU             | fxV             | fxAdd           | fxMult          |
	//  |-----------------|-----------------|-----------------|-----------------|
	//  | (float) 32 bits | (float) 32 bits | (float) 32 bits | (float) 32 bits |
	//
	//  | fxVp_u1         | fxVp_v1         | fxVp_u2         | fxVp_v2         |
	//  |-----------------|-----------------|-----------------|-----------------|
	//  | (float) 32 bits | (float) 32 bits | (float) 32 bits | (float) 32 bits |
	float  fxParams[MAX_ACTIVE_EFFECTS * 8];

	//  Three matrices per bone and an identity matrix for default bone.
	size_t newBoneMatricesSize = (composition->boneCount() * 3 + 1);
	if (renderBatch._uniformBoneMatrices.size() < newBoneMatricesSize)
	{
		renderBatch._uniformBoneMatrices.resize(newBoneMatricesSize);
	}

	//  1st bone matrix is identity.
	Math::Matrix4x4().getValues((float*)&renderBatch._uniformBoneMatrices[0]);

	//  Iterate on all bones and setup matrices used in uniform parameters.
	for (RD_Composition::BoneEffectCol_t::const_iterator i = composition->boneBegin(), iEnd = composition->boneEnd(); i != iEnd; ++i)
	{
		const RD_Composition::BoneEffect *boneEffect = *i;

		//  Copy bone matrix to render batch uniform parameters.
		boneEffect->_preMatrix.getValues((float*)&renderBatch._uniformBoneMatrices[(boneEffect->_effectIdx * 3 + 1)]);
		boneEffect->_matrix.getValues((float*)&renderBatch._uniformBoneMatrices[(boneEffect->_effectIdx * 3 + 2)]);
		boneEffect->_postMatrix.getValues((float*)&renderBatch._uniformBoneMatrices[(boneEffect->_effectIdx * 3 + 3)]);
	}

	//  Iterate on all composition nodes and create vertices to render. 
	for (RD_Composition::CompositionNodeCol_t::const_iterator i = iCompositionStart, iEnd = iCompositionEnd; i != iEnd; ++i)
	{
		const RD_Composition::CompositionNode *node = *i;
		if (node->_spriteName.empty())
			continue;

        const RD_SpriteSheet::SpriteData *spriteData = spriteSheet->sprite(node->_spriteName);

		if (!spriteData)
			continue;

		float u1, v1, u2, v2;
		int maskTextureId = spriteData->_textureId;
        RD_SpriteSheet::Rect rect = spriteData->_rect;
		if (spriteSheet->uvs(rect, spriteData->_textureId, u1, v1, u2, v2))
		{
			bool boneMappingDirty = false;

			SpriteMapping *spriteMapping = NULL;
			SpriteMappingCol_t::const_iterator iMapping = _i->_cachedMapping.find((CacheKey_t)spriteData);
			if (iMapping != _i->_cachedMapping.end())
			{
				//  Reuse existing sprite mapping for current sprite.
				spriteMapping = iMapping->second;
			}
			else
			{
				//  Create new sprite mapping for sprite and add to chached mappings.
				spriteMapping = createSpriteMapping(node, spriteData, _i->_discretizationStep);
				_i->_cachedMapping.insert(STD_MakePair((CacheKey_t)spriteData, spriteMapping));

				boneMappingDirty = true;
			}

			unsigned xSteps = spriteMapping->_xSteps;
			unsigned ySteps = spriteMapping->_ySteps;

			//  Transform coordinates using current matrix.
			float rectw = float(rect._w);
			float recth = float(rect._h);
			float x_2 = rectw * 0.5f;
			float y_2 = recth * 0.5f;

            

			//  Calculate and transform bounding coordinates.
			coords[COORD_X0] = coords[COORD_X3] = -x_2;
			coords[COORD_X1] = coords[COORD_X2] = x_2;
			coords[COORD_Y0] = coords[COORD_Y1] = -y_2;
			coords[COORD_Y2] = coords[COORD_Y3] = y_2;

			node->_matrix.multiplyPoint(&coords[COORD_X0], &coords[COORD_Y0]);
			node->_matrix.multiplyPoint(&coords[COORD_X1], &coords[COORD_Y1]);
			node->_matrix.multiplyPoint(&coords[COORD_X2], &coords[COORD_Y2]);
			node->_matrix.multiplyPoint(&coords[COORD_X3], &coords[COORD_Y3]);

			//  Iterate on all effects to retrieve viewports and 
			//  mix terms that are constant to every vertices.
			unsigned idx = 0;
			size_t nEffects = 0;
			if (node->_cutters.size() <= MAX_ACTIVE_EFFECTS)
			{
				//  Apply available effects.
				if (!node->_cutters.empty())
				{
					nEffects = node->_cutters.size();

					for (; idx < nEffects; ++idx)
					{
						const RD_Composition::CutterEffect *cutter = node->_cutters[idx];

						//  Attached matte, calculate matte uvs
						if (cutter->_nodeTreeView.isValid())
						{
							//  idx * 8
							unsigned fxIndex = idx << 3;

							//  Translate uvs from drawing coordinates to effect coordinates.
							if (spriteSheet->uvs(cutter->_spriteName, maskTextureId, &fxParams[fxIndex + FX_VP_U1_INDEX]))
							{
								TR_Types::EffectId_t effectId = cutter->_effectDataView->effectId();

								float add = (effectId == TR_Types::eCutter) ? 1.0f : 0.0f;
								float mult = (effectId == TR_Types::eCutter) ? -1.0f : 1.0f;

								fxParams[fxIndex + FX_ADD_INDEX] = add;
								fxParams[fxIndex + FX_MULT_INDEX] = mult;
							}
						}
					}
				}
			}

			//  Set remaining effects to default (add = 1, mult = 0)
			for (; idx < MAX_ACTIVE_EFFECTS; ++idx)
			{
				//  idx * 8
				unsigned fxIndex = idx << 3;

				//  Unused effect.
				fxParams[fxIndex + FX_ADD_INDEX] = 1.0f;     // add
				fxParams[fxIndex + FX_MULT_INDEX] = 0.0f;    // mult
			}

			//  Resize vertices array if required.
			size_t neededVertices = (xSteps + 1)*(ySteps + 1);
			size_t newVerticesSize = _i->_verticesCount + neededVertices;
			if (_i->_vertices.size() < newVerticesSize)
				_i->_vertices.resize(newVerticesSize);

			VertexData *vertexData = &_i->_vertices[_i->_verticesCount];

			//  Create vertices.
			for (unsigned yIndex = 0; yIndex <= ySteps; ++yIndex)
			{
				float ty = float(yIndex) / float(ySteps);
				float ty1 = 1.0f - ty;

				//  p1' = (x0,y0) + ((x3,y3) - (x0,y0)) * ty
				//  p2' = (x1,y1) + ((x2,y2) - (x1,y1)) * ty
				coords2[COORD_X0] = coords[COORD_X0] * ty1 + coords[COORD_X3] * ty;
				coords2[COORD_Y0] = coords[COORD_Y0] * ty1 + coords[COORD_Y3] * ty;

				coords2[COORD_X1] = coords[COORD_X1] * ty1 + coords[COORD_X2] * ty;
				coords2[COORD_Y1] = coords[COORD_Y1] * ty1 + coords[COORD_Y2] * ty;

				float vCoord = v2 + ty * (v1 - v2);

				for (unsigned xIndex = 0; xIndex <= xSteps; ++xIndex)
				{
					float tx = float(xIndex) / float(xSteps);
					float tx1 = 1.0f - tx;

					//  p3' = p1' + (p2' - p1') * tx
					vertexData->_x = coords2[COORD_X0] * tx1 + coords2[COORD_X1] * tx;
					vertexData->_y = coords2[COORD_Y0] * tx1 + coords2[COORD_Y1] * tx;
					vertexData->_z = 0.0f;

					vertexData->_opacity = node->_opacity;

					vertexData->_u0 = u1 + tx * (u2 - u1);
					vertexData->_v0 = vCoord;

					//  Iterate on all effects to calculate matte uvs.
					for (unsigned idx = 0; idx < nEffects; ++idx)
					{
						//  idx * 8
						unsigned fxIndex = idx << 3;

						float xMatte = vertexData->_x;
						float yMatte = vertexData->_y;

						const RD_Composition::CutterEffect *cutter = node->_cutters[idx];
						cutter->_matrix.multiplyPoint(&xMatte, &yMatte);

						float *fxViewport = &fxParams[fxIndex + FX_VP_U1_INDEX];

						float u0 = (fxViewport[0] + fxViewport[2]) * 0.5f;
						float v0 = (fxViewport[1] + fxViewport[3]) * 0.5f;

						float  width = (float)spriteSheet->width(maskTextureId);
						float  height = (float)spriteSheet->height(maskTextureId);
						fxParams[fxIndex + FX_U_INDEX] = u0 + (xMatte / width);
						fxParams[fxIndex + FX_V_INDEX] = v0 - (yMatte / height);
					}

					//  Retrieve bone mapping and update if not set.
					BoneMapping *boneMapping = spriteMapping->boneMapping(xIndex, yIndex);
					if (boneMappingDirty)
					{
						updateBoneMapping(node, vertexData->_x, vertexData->_y, boneMapping);
					}

					//  Copy cutter parameters to vertex data.
					memcpy(vertexData->_fxParams0, fxParams, sizeof(float) * MAX_ACTIVE_EFFECTS * 8);

					//  Copy bone parameters to vertex data.
					if (_i->_batches.size() == 1 
                        && (boneMapping->_boneIndex1 < MAX_BONES_GPUf) && (boneMapping->_boneIndex2 < MAX_BONES_GPUf))
					{
						memcpy(vertexData->_boneParams, boneMapping, sizeof(float) * 4);
					}
					//  Software fallback.  If bone indices are outside GPU array bounds, apply calculations directly on vertices.
					else
					{
						const float *skinMatrix1 = (const float*)&renderBatch._uniformBoneMatrices[(int)boneMapping->_boneIndex1];
						const float *skinMatrix2 = (const float*)&renderBatch._uniformBoneMatrices[(int)boneMapping->_boneIndex2];
						applyLinearBaseSkinning(boneMapping->_boneWeight1, skinMatrix1, boneMapping->_boneWeight2, skinMatrix2,
							vertexData->_x, vertexData->_y, vertexData->_x, vertexData->_y);

						//  Default mapping so that no deformation is applied on bone in GPU.
						memcpy(vertexData->_boneParams, &g_defaultMapping, sizeof(float) * 4);
					}

#ifdef UNITY_SUPPORT
					// This fixup used to be Unity side, but doing it here allows it to happen when its cache local,
					// and additionaly allows unity to use the memory directly as is, without copying, looping, and modifying before use.
					vertexData->_v0 = 1.0f - vertexData->_v0;
					vertexData->_fxParams0[1] = 1.0f - vertexData->_fxParams0[1];
					vertexData->_fxViewport0[1] = 1.0f - vertexData->_fxViewport0[1];
					vertexData->_fxViewport0[3] = 1.0f - vertexData->_fxViewport0[3];
#endif

					++vertexData;
				}
			}

			_i->_verticesCount = newVerticesSize;

			//  Resize indices array if required.
			size_t neededIndices = (xSteps)*(ySteps) * 6;
			size_t newIndicesSize = _i->_indicesCount + neededIndices;
			if (_i->_indices.size() < newIndicesSize)
				_i->_indices.resize(newIndicesSize);

			Index_t *indexArray = &_i->_indices[_i->_indicesCount];

			//  Create indices for vertices.
			for (Index_t yIndex = 0; yIndex < ySteps; ++yIndex)
			{
				for (Index_t xIndex = 0; xIndex < xSteps; ++xIndex)
				{
					Index_t index0 = index + yIndex * (xSteps + 1) + xIndex;
					Index_t index1 = index0 + 1;

					Index_t index3 = index0 + (xSteps + 1);
					Index_t index2 = index3 + 1;

					//  1st triangle.
					indexArray[0] = index0;
					indexArray[1] = index2;
					indexArray[2] = index1;

					//  2nd triangle.
					indexArray[3] = index0;
					indexArray[4] = index3;
					indexArray[5] = index2;

					indexArray += 6;
				}
			}

			_i->_indicesCount = newIndicesSize;

			_i->AddOrMergeTextureId(spriteData->_textureId, maskTextureId, neededIndices);

			index += neededVertices;
		}
	}

	renderBatch._nIndices = (unsigned)(_i->_indicesCount - renderBatch._indexOffset);
	renderBatch._nVertices = index - renderBatch._vertexOffset;
}

